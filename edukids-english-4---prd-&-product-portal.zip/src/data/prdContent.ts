import { TextbookInfo, UserPersona, PrdRisk } from '../types/prd';

export const PRODUCT_META = {
  title: 'EduKids English 4',
  subtitle: 'Tài liệu Yêu cầu Sản phẩm (PRD - Product Requirements Document)',
  version: '1.0.0-PROD',
  author: 'Senior EdTech Product Manager (10+ YOE Vietnam Market)',
  targetSegment: 'Học sinh Lớp 4 (9-10 tuổi) & Phụ huynh Việt Nam',
  curriculumCompliance: 'Thông tư 32/2018/TT-BGDĐT - Chương trình GDPT môn Tiếng Anh Lớp 4',
  supportedTextbooks: [
    'Global Success (NXB Giáo Dục Việt Nam - Pearson)',
    'Family and Friends National Edition (NXB Giáo Dục Việt Nam - Oxford)',
    'i-Learn Smart Start Grade 4 (NXB ĐH Sư Phạm TP.HCM - DTP Education)'
  ],
  dateCreated: '2026-11-12',
  status: 'Approved for Development (Sprint Ready)'
};

export const PERSONAS: UserPersona[] = [
  {
    id: 'student-primary',
    type: 'primary',
    name: 'Bé Nguyễn Minh Khôi',
    role: 'Primary User (Người học trực tiếp)',
    age: '9 tuổi (Học sinh lớp 4, Trường Tiểu học Dịch Vọng A, Cầu Giấy, Hà Nội)',
    avatar: '👦',
    bio: 'Khôi là cậu bé hiếu động, thích xem hoạt hình và chơi Roblox. Lớp 4 bắt đầu có nhiều từ vựng và bài tập ngữ pháp dài hơn lớp 3, Khôi bắt đầu thấy sợ giờ kiểm tra tiếng Anh vì sợ phát âm sai bị bạn cười.',
    painPoints: [
      'Nhanh chán khi phải nhìn vào trang sách giáo khoa giấy khô khan và chép từ vựng 10 lần.',
      'Sợ nói tiếng Anh vì không biết mình phát âm đúng hay sai, sợ bị thầy cô gọi đứng lên trước lớp.',
      'Dễ bị phân tâm bởi YouTube, TikTok, game khi được bố mẹ đưa điện thoại/máy tính bảng.',
      'Cảm giác "mất gốc" nhẹ các thì cơ bản và từ vựng từ lớp 3 khiến bài học lớp 4 trở nên quá tải.'
    ],
    goals: [
      'Muốn được chơi game vui vẻ mà vẫn được điểm 9, 10 trong bài kiểm tra định kỳ trên lớp.',
      'Tự tin phát âm chuẩn như người bản xứ trong video hoạt hình.',
      'Thu thập huy hiệu, mở khóa trang phục cho nhân vật thú cưng ảo (Mascot) để khoe bạn bè.'
    ],
    techHabits: [
      'Dùng iPad của gia đình hoặc điện thoại của mẹ 30-45 phút sau bữa tối.',
      'Thao tác chạm, kéo thả rất nhanh, thích phản hồi âm thanh (sound effects) vui nhộn, đồ họa rực rỡ.',
      'Ngại đọc các khối văn bản hướng dẫn dài quá 2 câu.'
    ],
    quote: '"Con muốn học tiếng Anh giống như đang chơi phiêu lưu vượt ải cùng bạn cún cưng Bibo!"'
  },
  {
    id: 'parent-secondary',
    type: 'secondary',
    name: 'Chị Trần Thu Hương',
    role: 'Buyer & Secondary User (Người ra quyết định mua & giám sát)',
    age: '36 tuổi (Mẹ của Khôi, Trưởng phòng Kế toán tại Hà Nội)',
    avatar: '👩‍💼',
    bio: 'Bận rộn đi làm cả ngày từ 8h sáng đến 18h tối. Chị rất quan tâm đến việc học của con nhưng vốn tiếng Anh hạn chế, không biết cách sửa phát âm cho con và không có thời gian ngồi kèm con học mỗi tối.',
    painPoints: [
      'Không biết phát âm tiếng Anh chuẩn nên không dám dạy con, sợ con học theo phát âm sai của mình.',
      'Áp lực điểm số thi học kỳ: Tiếng Anh lớp 4 là môn thi tính điểm học bạ, lo con bị tụt lại.',
      'Cho con mượn điện thoại thì sợ con bấm linh tinh, xem phải quảng cáo độc hại hoặc nghiện YouTube Shorts/Game.',
      'Các trung tâm tiếng Anh đắt đỏ (20-30 triệu/năm) nhưng không bám sát giáo trình SGK ở trường, đi thi ở trường điểm vẫn thấp.'
    ],
    goals: [
      'Muốn một giải pháp học tại nhà chỉ cần 20-25 phút mỗi ngày, bám 100% từng trang sách con đang học ở trường.',
      'Cần báo cáo minh bạch gửi thẳng vào Zalo: hôm nay con học từ gì, đúng bao nhiêu %, điểm yếu phát âm âm nào.',
      'Ứng dụng an toàn tuyệt đối 100% không quảng cáo, có cơ chế khóa bảo vệ mắt và quản lý thời gian.'
    ],
    techHabits: [
      'Sử dụng smartphone liên tục trong ngày, nhận tin tức chính qua Zalo và Facebook.',
      'Quen thanh toán qua Quét mã QR Ngân hàng (VietQR) hoặc MoMo, ngần ngại liên kết thẻ quốc tế.'
    ],
    quote: '"Tôi chỉ cần con bám sát sách Global Success ở lớp, tự giác học 20 phút mỗi ngày và tôi nhận được kết quả qua Zalo là tôi sẵn sàng trả phí năm!"'
  }
];

export const TEXTBOOKS: TextbookInfo[] = [
  {
    id: 'global-success',
    name: 'Tiếng Anh 4 - Global Success',
    publisher: 'NXB Giáo Dục Việt Nam hợp tác cùng Pearson Education',
    marketShare: '~65% thị phần cả nước (Phổ biến nhất tại miền Bắc & miền Trung)',
    totalUnits: 20,
    sampleUnit: {
      unitNumber: 1,
      title: 'Unit 1: My Friends',
      theme: 'Chào hỏi, giới thiệu bạn bè đến từ các quốc gia',
      targetVocab: [
        {
          word: 'Australia',
          ipa: '/ɒˈstreɪ.li.ə/',
          meaning: 'Nước Úc',
          phonemes: [
            { phoneme: 'Au', status: 'green' },
            { phoneme: 'stra', status: 'green' },
            { phoneme: 'li', status: 'yellow' },
            { phoneme: 'a', status: 'green' }
          ]
        },
        {
          word: 'America',
          ipa: '/əˈmer.ɪ.kə/',
          meaning: 'Nước Mỹ',
          phonemes: [
            { phoneme: 'A', status: 'green' },
            { phoneme: 'mer', status: 'green' },
            { phoneme: 'i', status: 'green' },
            { phoneme: 'ca', status: 'green' }
          ]
        },
        {
          word: 'Malaysia',
          ipa: '/məˈleɪ.ʒə/',
          meaning: 'Nước Ma-lai-xi-a',
          phonemes: [
            { phoneme: 'Ma', status: 'green' },
            { phoneme: 'lay', status: 'yellow' },
            { phoneme: 'sia', status: 'red' }
          ]
        },
        {
          word: 'Japan',
          ipa: '/dʒəˈpæn/',
          meaning: 'Nước Nhật Bản',
          phonemes: [
            { phoneme: 'Ja', status: 'green' },
            { phoneme: 'pan', status: 'green' }
          ]
        }
      ],
      targetSentence: 'Where is he/she from? - He/She is from Australia.',
      sampleConversation: [
        { speaker: 'Mai', text: 'Hi, Nam. This is my new friend, Ben.', vn: 'Chào Nam. Đây là người bạn mới của tớ, Ben.' },
        { speaker: 'Nam', text: 'Hello, Ben. Where are you from?', vn: 'Chào Ben. Bạn đến từ đâu vậy?' },
        { speaker: 'Ben', text: 'I am from Sydney, Australia.', vn: 'Tớ đến từ Sydney, nước Úc.' }
      ]
    }
  },
  {
    id: 'family-friends',
    name: 'Family and Friends National Edition 4',
    publisher: 'NXB Giáo Dục Việt Nam hợp tác cùng Oxford University Press',
    marketShare: '~22% thị phần (Rất phổ biến tại TP. Hồ Chí Minh và các tỉnh Nam Bộ)',
    totalUnits: 12,
    sampleUnit: {
      unitNumber: 1,
      title: 'Unit 1: They’re from Australia!',
      theme: 'Quốc tịch, sở thích và hoạt động lúc rảnh rỗi',
      targetVocab: [
        {
          word: 'Country',
          ipa: '/ˈkʌn.tri/',
          meaning: 'Quốc gia / Đất nước',
          phonemes: [
            { phoneme: 'Coun', status: 'green' },
            { phoneme: 'try', status: 'green' }
          ]
        },
        {
          word: 'Mexico',
          ipa: '/ˈmek.sɪ.kəʊ/',
          meaning: 'Nước Mê-hi-cô',
          phonemes: [
            { phoneme: 'Mex', status: 'green' },
            { phoneme: 'i', status: 'yellow' },
            { phoneme: 'co', status: 'green' }
          ]
        },
        {
          word: 'Flag',
          ipa: '/flæɡ/',
          meaning: 'Lá cờ',
          phonemes: [
            { phoneme: 'Fl', status: 'green' },
            { phoneme: 'ag', status: 'green' }
          ]
        }
      ],
      targetSentence: 'Where are they from? - They are from Mexico.',
      sampleConversation: [
        { speaker: 'Rosy', text: 'Look at the photo. Where are they from?', vn: 'Hãy nhìn bức ảnh này. Họ đến từ đâu?' },
        { speaker: 'Tim', text: 'They are from Brazil.', vn: 'Họ đến từ nước Brazil.' }
      ]
    }
  },
  {
    id: 'smart-start',
    name: 'i-Learn Smart Start Grade 4',
    publisher: 'NXB ĐH Sư Phạm TP.HCM kết hợp DTP Education Software',
    marketShare: '~13% thị phần (Phổ biến tại các tỉnh Đồng bằng sông Cửu Long & Duyên hải miền Trung)',
    totalUnits: 8,
    sampleUnit: {
      unitNumber: 1,
      title: 'Theme 1: Time & Daily Routines',
      theme: 'Thời gian biểu và thói quen sinh hoạt hàng ngày',
      targetVocab: [
        {
          word: 'O\'clock',
          ipa: '/əˈklɒk/',
          meaning: 'Giờ đúng',
          phonemes: [
            { phoneme: 'O\'', status: 'green' },
            { phoneme: 'clock', status: 'green' }
          ]
        },
        {
          word: 'Breakfast',
          ipa: '/ˈbrek.fəst/',
          meaning: 'Bữa ăn sáng',
          phonemes: [
            { phoneme: 'Break', status: 'green' },
            { phoneme: 'fast', status: 'green' }
          ]
        }
      ],
      targetSentence: 'What time do you have breakfast? - I have breakfast at seven o\'clock.',
      sampleConversation: [
        { speaker: 'Tom', text: 'What time is it, Alfie?', vn: 'Mấy giờ rồi hả Alfie?' },
        { speaker: 'Alfie', text: 'It is six thirty. Time for breakfast!', vn: 'Sáu giờ ba mươi rồi. Đến giờ ăn sáng rồi!' }
      ]
    }
  }
];

export const PRD_RISKS: PrdRisk[] = [
  {
    id: 'risk-1',
    category: 'Công nghệ AI',
    risk: 'AI Speech Recognition nhận diện sai giọng trẻ em Việt Nam (giọng the thé, ngọng nguyên âm /æ/, /ə/, thiếu phụ âm cuối /s/, /t/, /d/, ảnh hưởng giọng địa phương Bắc - Trung - Nam).',
    impact: 'Cao',
    probability: 'Cao',
    mitigation: 'Tập trung Fine-tune mô hình ASR chuyên biệt bằng tập dữ liệu 50,000+ mẫu âm thanh trẻ em Việt Nam lứa tuổi 8-11 tuổi. Sử dụng thuật toán Acoustic Phoneme Alignment linh hoạt với biên độ dung sai (tolerance margin) cho phép phát âm gần đúng ở vòng đầu, kèm gợi ý khẩu hình miệng video 3D Mascot để bé sửa dần.'
  },
  {
    id: 'risk-2',
    category: 'Học liệu & Pháp lý',
    risk: 'Sách giáo khoa có thể được chỉnh lý nội dung nhỏ theo đợt thẩm định hàng năm của Bộ GD&ĐT hoặc bản quyền hình ảnh minh họa SGK.',
    impact: 'Cao',
    probability: 'Trung bình',
    mitigation: 'Xây dựng kiến trúc Headless CMS cho học liệu: Nội dung từ vựng, audio, bài tập được tải động từ Cloud Server (Firebase/Cloud Storage) chứ không đóng cứng (hardcode) trong ứng dụng. Hình ảnh minh họa được đội ngũ Artist vẽ độc quyền 100% bám sát nội dung bài học nhưng không sao chép nguyên bản tranh vẽ SGK giấy để tránh vi phạm bản quyền.'
  },
  {
    id: 'risk-3',
    category: 'Hành vi & Trẻ em',
    risk: 'Học sinh quá ham tính năng game/đổi quà dẫn đến dán mắt vào màn hình quá lâu, gây phản ứng tiêu cực từ phụ huynh.',
    impact: 'Trung bình',
    probability: 'Cao',
    mitigation: 'Thiết lập tính năng "Khóa mắt khỏe & Nghỉ giải lao" (Break Timer): Sau 20 phút học liên tục, ứng dụng tự động hiển thị màn hình Mascot nhắc nhở bài tập nhìn xa 20 feet trong 20 giây (Quy tắc 20-20-20 của y tế). Giới hạn tối đa 40 phút học/ngày trừ khi phụ huynh mở khóa bằng Parental Gate.'
  },
  {
    id: 'risk-4',
    category: 'Thương mại & Thanh toán',
    risk: 'Tỷ lệ phụ huynh bỏ rơi giỏ hàng cao do ngại thanh toán qua Apple App Store / Google Play (đòi hỏi thẻ Visa/MasterCard).',
    impact: 'Cao',
    probability: 'Cao',
    mitigation: 'Tích hợp cổng thanh toán nội địa đa kênh gồm VietQR chuyển khoản ngân hàng (tự động khớp lệnh webhook trong 5 giây), ví điện tử MoMo, ZaloPay và VNPay. Giảm thiểu rào cản bằng chương trình Dùng thử 7 ngày không cần nhập thẻ.'
  }
];

export const KPI_METRICS = [
  {
    id: 'kpi-1',
    metric: 'DAU / MAU Ratio (Độ gắn bó của học sinh)',
    target: '≥ 42%',
    benchmark: 'Trung bình ngành EdTech trẻ em là 28-35%',
    formula: 'Daily Active Users / Monthly Active Users',
    importance: 'Cực kỳ quan trọng để duy trì thói quen học hàng ngày'
  },
  {
    id: 'kpi-2',
    metric: 'Retention Rate D7 & D30 (Tỷ lệ giữ chân)',
    target: 'D7 ≥ 55%, D30 ≥ 32%',
    benchmark: 'Chuẩn Top 10% ứng dụng giáo dục trên App Store',
    formula: 'Số user quay lại học vào ngày thứ N / Số user đăng ký mới',
    importance: 'Quyết định tính bền vững của mô hình kinh doanh'
  },
  {
    id: 'kpi-3',
    metric: 'Unit Completion Rate (Tỷ lệ hoàn thành bài)',
    target: '≥ 75%',
    benchmark: 'Tỷ lệ hoàn thành các Lesson 1, 2, 3 trong 1 Unit',
    formula: 'Số bài học hoàn thành đạt ≥ 80% điểm / Tổng số bài bắt đầu',
    importance: 'Đo lường tính hiệu quả sư phạm và độ hấp dẫn bài giảng'
  },
  {
    id: 'kpi-4',
    metric: 'Free-to-Paid Conversion (Chuyển đổi trả phí)',
    target: '≥ 6.8%',
    benchmark: 'Thị trường EdTech VN dao động 3.5% - 5.0%',
    formula: 'Số tài khoản kích hoạt VIP / Tổng số tài khoản phụ huynh đăng ký',
    importance: 'Động cơ chính tạo doanh thu và khả năng hòa vốn (Payback period)'
  },
  {
    id: 'kpi-5',
    metric: 'Speech AI Latency P95 (Tốc độ phản hồi)',
    target: '< 1,800 ms',
    benchmark: 'Yêu cầu không làm gián đoạn nhịp hào hứng của trẻ 9-10 tuổi',
    formula: 'Thời gian từ lúc dứt lời nói đến khi màn hình hiện điểm âm tiết',
    importance: 'Trải nghiệm mượt mà, không bị lag làm bé nản chí'
  }
];
