import { UserStory } from '../types/prd';

export const USER_STORIES_BACKLOG: UserStory[] = [
  {
    id: 'US-01',
    module: 'Module 1: Hệ thống học liệu SGK Lớp 4',
    epic: 'Quản lý giáo trình & Cấu trúc bài học',
    title: 'Chọn và chuyển đổi bộ Sách Giáo Khoa Lớp 4',
    asA: 'Phụ huynh hoặc học sinh lớp 4',
    iWantTo: 'chọn bộ sách giáo khoa tiếng Anh bé đang học ở trường (Global Success, Family & Friends, i-Learn Smart Start)',
    soThat: 'mọi bài học, từ vựng và bài tập trong ứng dụng hoàn toàn khớp 100% với chương trình trên lớp của bé.',
    acceptanceCriteria: [
      'Hệ thống hiển thị trực quan bìa sách và tên nhà xuất bản của 3 bộ sách chính: Global Success, Family and Friends National Edition, i-Learn Smart Start.',
      'Khi người dùng chọn một bộ sách, toàn bộ lộ trình bài học tự động cập nhật đúng danh sách 16-20 Units của bộ sách đó.',
      'Người dùng có thể chuyển đổi bộ sách bất cứ lúc nào trong mục Cài đặt / Hồ sơ mà không làm mất lịch sử học tập hay điểm tích lũy.',
      'Hệ thống lưu lại tiến độ riêng biệt cho từng bộ sách nếu phụ huynh có nhu cầu cho con học song song.'
    ],
    priority: 'Must Have',
    phase: 'MVP (Giai đoạn 1)',
    storyPoints: 5,
    technicalNotes: 'Lưu trữ state `current_curriculum_id` trong LocalStorage và đồng bộ Firebase User Profile.'
  },
  {
    id: 'US-02',
    module: 'Module 1: Hệ thống học liệu SGK Lớp 4',
    epic: 'Học từ vựng đa giác quan',
    title: 'Học từ vựng theo Unit với Flashcard tương tác & âm thanh chuẩn',
    asA: 'Học sinh lớp 4',
    iWantTo: 'xem thẻ Flashcard chứa hình vẽ sinh động, nghe giọng đọc bản xứ chuẩn Anh-Anh / Anh-Mỹ và xem phiên âm IPA',
    soThat: 'con nhớ nghĩa của từ nhanh chóng và hiểu cách phát âm đúng trước khi tự luyện nói.',
    acceptanceCriteria: [
      'Mỗi Unit chứa đúng danh mục 8-15 từ vựng trọng tâm của Unit đó theo SGK.',
      'Thẻ Flashcard có nút lật 2 mặt (Mặt trước: Hình vẽ minh họa độc quyền + Từ tiếng Anh + Nút loa nghe giọng đọc bản xứ; Mặt sau: Phiên âm IPA + Nghĩa tiếng Việt + Câu ví dụ mẫu).',
      'Có nút điều chỉnh tốc độ đọc âm thanh (Bình thường 1.0x và Chậm 0.75x) để trẻ nghe rõ từng âm gió.',
      'Có nút đánh dấu "Từ vựng yêu thích / Cần ôn lại" để gom vào sổ tay từ khó.'
    ],
    priority: 'Must Have',
    phase: 'MVP (Giai đoạn 1)',
    storyPoints: 5,
    technicalNotes: 'Audio MP3 tối ưu CDN, prefetch trước 3 thẻ tiếp theo để đảm bảo lật thẻ 0ms giật lag.'
  },
  {
    id: 'US-03',
    module: 'Module 2: AI Luyện phát âm & Giao tiếp',
    epic: 'AI Speech Recognition & Phoneme Scoring',
    title: 'Chấm điểm phát âm chi tiết theo từng âm tiết (Phoneme-level)',
    asA: 'Học sinh lớp 4',
    iWantTo: 'bấm nút micro và đọc từ vựng hoặc câu mẫu để AI chấm điểm từng âm tiết bằng màu sắc',
    soThat: 'con biết chính xác mình phát âm chuẩn hay sai ở âm nào (ví dụ thiếu âm đuôi /s/, /t/ hay sai nguyên âm) để sửa ngay.',
    acceptanceCriteria: [
      'Giao diện hiển thị nút Micro to, trực quan, có hiệu ứng sóng âm (Waveform) khi đang thu âm.',
      'Thời gian phản hồi AI từ lúc dừng nói đến khi hiển thị kết quả không vượt quá 1.8 giây.',
      'Hiển thị từ vựng với các âm tiết được tô màu phân cấp rõ ràng: Màu Xanh lá (Chuẩn ≥ 85%), Màu Vàng (Tạm được 65-84%), Màu Đỏ (Cần sửa < 65%).',
      'Nếu đạt điểm Xanh lá, hệ thống phát âm thanh reo hò (cheer effect) và cộng 3 Sao thưởng; nếu có âm Đỏ, nhân vật Mascot đưa ra mẹo uốn lưỡi thân thiện.',
      'Cho phép bé bấm trực tiếp vào âm tiết bị Đỏ để nghe lại âm thanh mẫu của riêng âm tiết đó.'
    ],
    priority: 'Must Have',
    phase: 'MVP (Giai đoạn 1)',
    storyPoints: 8,
    technicalNotes: 'Tích hợp ASR Audio Worklet, trích xuất MFCC, đối sánh Acoustic Alignment theo CMU Pronouncing Dictionary.'
  },
  {
    id: 'US-04',
    module: 'Module 2: AI Luyện phát âm & Giao tiếp',
    epic: 'Hội thoại tương tác Role-play',
    title: 'Đóng vai nhân vật trong đoạn hội thoại SGK (Role-play with AI)',
    asA: 'Học sinh lớp 4',
    iWantTo: 'chọn đóng vai bạn Mai, Nam, Ben hay Tom trong các đoạn hội thoại thực tế của SGK',
    soThat: 'con thực hành phản xạ giao tiếp tự nhiên và ứng dụng cấu trúc câu vào ngữ cảnh thực tế.',
    acceptanceCriteria: [
      'Hiển thị hoạt cảnh truyện tranh tương tác giữa 2 nhân vật theo đúng bài hội thoại Lesson 1 / Lesson 2.',
      'AI đọc lời thoại của nhân vật A, sau đó dừng lại và hiển thị gợi ý câu thoại cho bé (nhân vật B) nói.',
      'Hệ thống nhận diện giọng nói của bé, nếu độ chính xác câu đạt ≥ 70%, hoạt cảnh tự động tiếp diễn sang lời thoại tiếp theo.',
      'Có nút "Nghe lại cả đoạn hội thoại" và nút "Dịch nghĩa toàn bài" để bé hiểu toàn cảnh.'
    ],
    priority: 'Should Have',
    phase: 'Phase 2 (Mở rộng)',
    storyPoints: 8,
    technicalNotes: 'Sử dụng LLM Gemini API xử lý kịch bản động và đối thoại mở rộng nếu học sinh phát âm câu biến thể hợp lệ.'
  },
  {
    id: 'US-05',
    module: 'Module 3: Hệ thống Game hóa (Gamification)',
    epic: 'Hệ thống Động lực & Phần thưởng',
    title: 'Nuôi thú cưng Mascot ảo và duy trì chuỗi Streak học tập',
    asA: 'Học sinh lớp 4',
    iWantTo: 'chăm sóc chú cún Bibo, tích lũy Sao/Kim cương mỗi ngày và duy trì ngọn lửa Streak',
    soThat: 'con luôn có động lực vào app học mỗi ngày mà không cần bố mẹ phải nhắc nhở hay quát mắng.',
    acceptanceCriteria: [
      'Nhân vật Mascot Bibo chào đón bé bằng giọng nói thân thiện, biểu cảm vui vẻ khi bé hoàn thành bài và buồn ngủ khi bé lười học.',
      'Mỗi bài học hoàn thành được thưởng từ 1 đến 3 Sao (dựa trên % điểm số) và 10-30 Kim Cương.',
      'Hiển thị biểu tượng Ngọn Lửa Streak (chuỗi ngày học liên tục); học liên tục 7 ngày được mở khóa rương báu đặc biệt.',
      'Có cửa hàng phụ kiện ảo (Avatar Shop) để bé dùng Kim Cương mua mũ nón, kính râm, ba lô cho Bibo (hoàn toàn là tiền ảo, không nạp tiền thật mua đồ).'
    ],
    priority: 'Must Have',
    phase: 'MVP (Giai đoạn 1)',
    storyPoints: 5,
    technicalNotes: 'Client lưu cache streak; server kiểm tra múi giờ GMT+7 để reset streak lúc 00:00 mỗi ngày.'
  },
  {
    id: 'US-06',
    module: 'Module 3: Hệ thống Game hóa (Gamification)',
    epic: 'Bảng xếp hạng an toàn',
    title: 'Bảng xếp hạng thi đua tuần cùng các bạn đồng trang lứa',
    asA: 'Học sinh lớp 4',
    iWantTo: 'xem thứ hạng của mình trong bảng thi đua học tập tuần',
    soThat: 'con có tinh thần phấn đấu vươn lên top đầu và nhận huy hiệu danh dự.',
    acceptanceCriteria: [
      'Bảng xếp hạng gom nhóm ngẫu nhiên 30 học sinh cùng trình độ trong tuần để tránh cảm giác choáng ngợp hay tự ti.',
      'Bảo vệ quyền riêng tư tuyệt đối: Chỉ hiển thị tên gọi thân mật (ví dụ: Bé Bắp, Minh Khôi) và Avatar hoạt hình, KHÔNG hiển thị họ tên đầy đủ, trường lớp hay số điện thoại.',
      'Top 3 cuối tuần nhận Cúp vinh danh và Kim Cương thưởng.',
      'Reset bảng xếp hạng vào 23:59 Chủ Nhật hàng tuần.'
    ],
    priority: 'Should Have',
    phase: 'MVP (Giai đoạn 1)',
    storyPoints: 5,
    technicalNotes: 'Leaderboard phân mảnh (Partitioned Redis leaderboard) chia theo Tier (Bronze, Silver, Gold).'
  },
  {
    id: 'US-07',
    module: 'Module 4: Kho đề ôn thi Giữa kỳ & Cuối kỳ',
    epic: 'Khảo thí chuẩn Bộ GD&ĐT',
    title: 'Làm bài thi thử Giữa kỳ / Cuối kỳ chuẩn định dạng Bộ GD&ĐT',
    asA: 'Học sinh lớp 4 và phụ huynh',
    iWantTo: 'cho bé làm các bộ đề thi thử có tính thời gian bám sát cấu trúc đề kiểm tra trên lớp',
    soThat: 'bé làm quen với áp lực phòng thi và biết được dự kiến điểm số thật ở trường.',
    acceptanceCriteria: [
      'Kho đề thi gồm 2 học kỳ (Học kỳ 1 & Học kỳ 2), chia làm Đề Giữa kỳ và Đề Cuối kỳ cho từng bộ SGK.',
      'Cấu trúc đề đủ 3 kỹ năng theo chuẩn Bộ GD&ĐT: Listening (Nghe tranh/nối/điền từ), Reading (Đọc hiểu đoạn văn), Writing (Sắp xếp trật tự từ, viết câu).',
      'Đồng hồ đếm ngược 35-40 phút có cảnh báo màu vàng khi còn 5 phút cuối.',
      'Chấm điểm tự động thang điểm 10 ngay khi nộp bài, hiển thị đáp án chi tiết và lời giải thích bằng tiếng Việt dễ hiểu.'
    ],
    priority: 'Must Have',
    phase: 'MVP (Giai đoạn 1)',
    storyPoints: 8,
    technicalNotes: 'Trộn ngẫu nhiên câu hỏi từ ngân hàng 500+ câu hỏi trắc nghiệm đã được giáo viên kiểm định.'
  },
  {
    id: 'US-08',
    module: 'Module 5: Khu vực Phụ huynh & Zalo OA',
    epic: 'Parental Control & Báo cáo học tập',
    title: 'Cổng bảo vệ phụ huynh (Parental Gate) và Báo cáo tự động qua Zalo',
    asA: 'Phụ huynh học sinh',
    iWantTo: 'có cổng khóa mã PIN/phép tính bảo vệ và nhận báo cáo tiến độ học của con qua tin nhắn Zalo hàng tuần',
    soThat: 'tôi nắm rõ con tiến bộ ra sao, con đang yếu phần nào mà không cần kè kè ngồi cạnh con.',
    acceptanceCriteria: [
      'Khi nhấn vào nút "Góc Phụ Huynh", hệ thống hiển thị câu hỏi bảo vệ (Phép nhân ngẫu nhiên như: 7 × 8 = ? hoặc nhập mã PIN 4 số của bố mẹ) để trẻ không tự ý truy cập.',
      'Báo cáo trực quan hiển thị: Tổng thời gian học trong tuần, Số từ vựng đã nắm vững, Điểm phát âm trung bình, và Top 3 từ phát âm sai nhiều nhất cần lưu ý.',
      'Tính năng liên kết tài khoản Zalo: Tự động gửi tin nhắn tổng kết tuần (Weekly Digest) vào 20:00 tối Chủ Nhật qua Zalo Official Account (Zalo OA).',
      'Cài đặt giới hạn thời gian học mỗi ngày (mặc định 20 phút), sau thời gian này app tự khóa và chuyển sang màn hình bảo vệ mắt.'
    ],
    priority: 'Must Have',
    phase: 'MVP (Giai đoạn 1)',
    storyPoints: 8,
    technicalNotes: 'Tích hợp Zalo ZNS (Zalo Notification Service) Template đã được phê duyệt, gửi webhook event từ backend.'
  },
  {
    id: 'US-09',
    module: 'Module 6: Thanh toán & Gói cước',
    epic: 'Monetization & Cổng thanh toán nội địa',
    title: 'Nâng cấp gói cước VIP qua VietQR, MoMo và In-App Purchase',
    asA: 'Phụ huynh học sinh',
    iWantTo: 'chọn mua gói cước học tập linh hoạt (1 tháng, 6 tháng, 1 năm) và thanh toán nhanh chóng bằng quét mã QR ngân hàng hoặc ví MoMo',
    soThat: 'tôi kích hoạt ngay tài khoản VIP cho con học mà không gặp rắc rối thẻ tín dụng.',
    acceptanceCriteria: [
      'Bảng so sánh tính năng rõ ràng giữa Gói Miễn Phí (học 2 Unit đầu + 3 lần luyện phát âm/ngày) và Gói VIP Không Giới Hạn (20 Unit, Kho đề thi, AI phát âm vô hạn, Báo cáo Zalo chi tiết).',
      'Hỗ trợ 3 phương thức thanh toán: VietQR Ngân hàng (chuyển khoản tự động duyệt trong 5 giây), Ví điện tử MoMo/ZaloPay, và Apple IAP / Google Play Billing.',
      'Hiển thị rõ ràng cam kết: Hoàn tiền trong 7 ngày nếu không hài lòng, không tự động gia hạn ẩn đối với phương thức chuyển khoản QR.',
      'Tặng kèm Ebook "Sổ tay 200 mẫu câu tiếng Anh Lớp 4 bám sát SGK" khi đăng ký gói 1 năm.'
    ],
    priority: 'Must Have',
    phase: 'MVP (Giai đoạn 1)',
    storyPoints: 5,
    technicalNotes: 'Webhook lắng nghe tín hiệu Payment Gateway (Sepay/Cassova hoặc MoMo IPN) để tự động nâng cấp quyền VIP tức thì.'
  }
];
