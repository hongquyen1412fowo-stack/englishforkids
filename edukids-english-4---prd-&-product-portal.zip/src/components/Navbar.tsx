import React from 'react';
import { 
  FileText, 
  CheckSquare, 
  Gamepad2, 
  BarChart3, 
  Cpu, 
  Download, 
  Printer, 
  Sparkles,
  BookOpen
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onExportMarkdown: () => void;
  onPrint: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onExportMarkdown,
  onPrint
}) => {
  const navTabs = [
    { id: 'document', label: 'Toàn văn PRD', icon: FileText, badge: 'Chi tiết' },
    { id: 'user-stories', label: 'User Stories & Backlog', icon: CheckSquare, badge: '9 Stories' },
    { id: 'prototype', label: 'Interactive Sandbox', icon: Gamepad2, badge: 'Trải nghiệm' },
    { id: 'metrics', label: 'EdTech KPIs & Funnel', icon: BarChart3, badge: 'Tài chính' },
    { id: 'architecture', label: 'Kiến trúc & AI Pipeline', icon: Cpu, badge: 'Kỹ thuật' }
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-500 to-amber-400 flex items-center justify-center text-white shadow-md shadow-amber-500/20 font-bold text-xl">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-lg text-slate-900 tracking-tight">
                  EduKids English 4
                </span>
                <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">
                  SGK Lớp 4
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800 border border-emerald-200">
                  v1.0 PRD Ready
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Product Requirements Document • Chuẩn Bộ GD&ĐT Việt Nam
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center space-x-2">
            <button
              onClick={onExportMarkdown}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors border border-slate-200 cursor-pointer"
              title="Xuất tài liệu PRD dạng Markdown (.md)"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden md:inline">Tải PRD (.MD)</span>
            </button>
            <button
              onClick={onPrint}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors border border-slate-200 cursor-pointer"
              title="In hoặc Lưu thành PDF"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden md:inline">In / PDF</span>
            </button>
            <div className="h-6 w-px bg-slate-200 mx-1 hidden sm:block" />
            <div className="hidden lg:flex items-center space-x-1 text-xs text-slate-600 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200/70">
              <Sparkles className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
              <span className="font-medium text-amber-900">Senior PM 10+ YOE Vietnam EdTech</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 overflow-x-auto pb-2 sm:pb-0 scrollbar-none border-t border-slate-100 pt-1">
          {navTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-3.5 py-2.5 text-xs sm:text-sm font-semibold rounded-t-lg transition-all duration-150 whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'text-amber-600 bg-amber-50/60 border-b-2 border-amber-600'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-600' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`ml-1 text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                      isActive
                        ? 'bg-amber-200/80 text-amber-900'
                        : 'bg-slate-200/70 text-slate-600'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
