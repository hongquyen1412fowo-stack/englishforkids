import React, { useState, useEffect } from 'react';
import { TEXTBOOKS } from '../data/prdContent';
import { 
  Volume2, 
  Mic, 
  RotateCcw, 
  Sparkles, 
  ShieldAlert, 
  Flame, 
  Star, 
  Lock, 
  Unlock, 
  CheckCircle2, 
  AlertCircle, 
  Send, 
  Clock, 
  QrCode, 
  ChevronRight,
  BookOpen,
  VolumeX,
  Smartphone,
  Eye,
  Gift
} from 'lucide-react';

export const InteractivePrototype: React.FC = () => {
  const [activeMode, setActiveMode] = useState<'student' | 'parent'>('student');
  const [selectedBookId, setSelectedBookId] = useState<'global-success' | 'family-friends' | 'smart-start'>('global-success');
  
  // Student Sandbox State
  const currentBook = TEXTBOOKS.find(b => b.id === selectedBookId) || TEXTBOOKS[0];
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [audioSpeed, setAudioSpeed] = useState<number>(1.0);
  const [isRecording, setIsRecording] = useState(false);
  const [speechResult, setSpeechResult] = useState<{
    score: number;
    phonemes: { phoneme: string; score: number; status: 'green' | 'yellow' | 'red' }[];
    feedback: string;
  } | null>(null);
  const [stars, setStars] = useState(124);
  const [streakDays, setStreakDays] = useState(5);
  const [mascotMood, setMascotMood] = useState<'happy' | 'cheer' | 'thinking'>('happy');

  // Parent Zone State
  const [isParentGateLocked, setIsParentGateLocked] = useState(true);
  const [parentMathAnswer, setParentMathAnswer] = useState('');
  const [parentGateError, setParentGateError] = useState(false);
  const [screenTimeSpent, setScreenTimeSpent] = useState(18); // minutes
  const [screenLimit, setScreenLimit] = useState(20); // minutes
  const [zaloSent, setZaloSent] = useState(false);
  const [showVipModal, setShowVipModal] = useState(false);
  const [selectedVipPlan, setSelectedVipPlan] = useState<'6m' | '1y'>('1y');

  const currentVocab = currentBook.sampleUnit.targetVocab[currentWordIndex] || currentBook.sampleUnit.targetVocab[0];

  // Audio Playback
  const playNativeAudio = (text: string, speed = 1.0) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      utterance.rate = speed;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Simulate or execute speech recognition
  const handleStartMic = () => {
    setIsRecording(true);
    setMascotMood('thinking');
    setSpeechResult(null);

    // Simulate real speech analysis with slight delay
    setTimeout(() => {
      setIsRecording(false);
      // Generate realistic phoneme evaluation
      const samplePhonemes = currentVocab.phonemes.map((p, idx) => {
        // First phonemes usually high, last sometimes lower to demonstrate red/yellow
        const isLast = idx === currentVocab.phonemes.length - 1;
        const score = isLast && p.status === 'red' ? 58 : isLast && p.status === 'yellow' ? 76 : 94;
        return {
          phoneme: p.phoneme,
          score,
          status: score >= 85 ? ('green' as const) : score >= 65 ? ('yellow' as const) : ('red' as const)
        };
      });

      const totalScore = Math.round(samplePhonemes.reduce((a, b) => a + b.score, 0) / samplePhonemes.length);
      
      setSpeechResult({
        score: totalScore,
        phonemes: samplePhonemes,
        feedback: totalScore >= 85 
          ? 'Tuyệt vời! Bé phát âm chuẩn như người bản xứ!' 
          : 'Gần đúng rồi! Bé chú ý bật rõ âm cuối nhé!'
      });

      if (totalScore >= 80) {
        setMascotMood('cheer');
        setStars(prev => prev + 3);
      } else {
        setMascotMood('happy');
      }
    }, 1600);
  };

  const handleParentGateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (parentMathAnswer.trim() === '56') { // 7 x 8 = 56
      setIsParentGateLocked(false);
      setParentGateError(false);
    } else {
      setParentGateError(true);
    }
  };

  const handleSendZaloDigest = () => {
    setZaloSent(true);
    setTimeout(() => setZaloSent(false), 5000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Prototype Control Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-200 gap-4 mb-6">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800">
              Interactive Prototype Sandbox
            </span>
            <span className="text-xs text-slate-500 font-medium">Trải nghiệm tương tác thực tế</span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 mt-1">
            Mô Phỏng Trải Nghiệm Học Sinh & Phụ Huynh
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Trải nghiệm trực tiếp AI Speech Recognition chấm điểm âm tiết, Mascot Bibo, Khóa phụ huynh Parental Gate và Báo cáo Zalo.
          </p>
        </div>

        {/* Mode Switcher */}
        <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200 shrink-0">
          <button
            onClick={() => setActiveMode('student')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeMode === 'student'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>👦 Học sinh Lớp 4 (Core Loop)</span>
          </button>
          <button
            onClick={() => setActiveMode('parent')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeMode === 'parent'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>👩‍💼 Góc Phụ Huynh & Zalo OA</span>
          </button>
        </div>
      </div>

      {/* MODE 1: STUDENT LEARNING LOOP */}
      {activeMode === 'student' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Learning Canvas */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Textbook Switcher Tabs */}
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs font-bold text-slate-700 flex items-center">
                <BookOpen className="w-4 h-4 text-amber-600 mr-1.5" />
                Chọn SGK bé đang học:
              </span>
              <div className="flex space-x-2">
                {TEXTBOOKS.map((tb) => (
                  <button
                    key={tb.id}
                    onClick={() => {
                      setSelectedBookId(tb.id);
                      setCurrentWordIndex(0);
                      setIsFlipped(false);
                      setSpeechResult(null);
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      selectedBookId === tb.id
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {tb.name.split(' - ')[0]}
                  </button>
                ))}
              </div>
            </div>

            {/* Top Bar for Kid: Streak & Stars */}
            <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 rounded-2xl p-4 text-white flex items-center justify-between shadow-md">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1.5 bg-black/20 px-3 py-1 rounded-full text-xs font-bold">
                  <Flame className="w-4 h-4 text-amber-300 animate-bounce" />
                  <span>{streakDays} Ngày liên tiếp</span>
                </div>
                <div className="flex items-center space-x-1.5 bg-black/20 px-3 py-1 rounded-full text-xs font-bold">
                  <Star className="w-4 h-4 text-yellow-300 fill-yellow-300" />
                  <span>{stars} Sao</span>
                </div>
              </div>
              <span className="text-xs font-bold bg-white/20 px-3 py-1 rounded-full">
                {currentBook.sampleUnit.title}
              </span>
            </div>

            {/* Flashcard & AI Speech Grader Area */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm relative">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Từ {currentWordIndex + 1} / {currentBook.sampleUnit.targetVocab.length}
                </span>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-slate-500 font-medium">Tốc độ đọc:</span>
                  <button
                    onClick={() => setAudioSpeed(audioSpeed === 1.0 ? 0.75 : 1.0)}
                    className="px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-100 text-slate-800 hover:bg-slate-200 cursor-pointer"
                  >
                    {audioSpeed}x {audioSpeed === 0.75 && '(Chậm)'}
                  </button>
                </div>
              </div>

              {/* Interactive Flashcard */}
              <div 
                onClick={() => setIsFlipped(!isFlipped)}
                className="bg-gradient-to-br from-amber-50/60 via-white to-amber-100/40 border-2 border-amber-300/80 rounded-3xl p-8 text-center cursor-pointer transition-all hover:shadow-md min-h-[240px] flex flex-col items-center justify-center relative select-none"
              >
                <span className="absolute top-4 right-4 text-[11px] font-semibold text-amber-700 bg-amber-200/60 px-2.5 py-0.5 rounded-full">
                  Chạm để lật nghĩa 🔄
                </span>

                {!isFlipped ? (
                  <div>
                    <div className="text-6xl mb-3">
                      {currentVocab.word === 'Australia' ? '🦘' : currentVocab.word === 'America' ? '🗽' : currentVocab.word === 'Japan' ? '🗾' : '🚩'}
                    </div>
                    <h3 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight mb-2">
                      {currentVocab.word}
                    </h3>
                    <p className="font-mono text-slate-500 text-sm">
                      {currentVocab.ipa}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2 animate-fadeIn">
                    <span className="text-xs font-bold text-slate-400 uppercase">Nghĩa tiếng Việt</span>
                    <h4 className="text-2xl sm:text-3xl font-extrabold text-amber-800">
                      {currentVocab.meaning}
                    </h4>
                    <p className="text-xs text-slate-600 max-w-sm mx-auto pt-2">
                      Mẫu câu ví dụ: <strong>Where is he from? - He is from {currentVocab.word}.</strong>
                    </p>
                  </div>
                )}
              </div>

              {/* Action Controls */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-6">
                {/* Listen Native Speaker */}
                <button
                  onClick={() => playNativeAudio(currentVocab.word, audioSpeed)}
                  className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-5 py-3 rounded-2xl font-bold text-xs sm:text-sm bg-slate-100 text-slate-800 hover:bg-slate-200 border border-slate-300 transition-all cursor-pointer"
                >
                  <Volume2 className="w-5 h-5 text-amber-600" />
                  <span>Nghe cô giáo đọc ({audioSpeed}x)</span>
                </button>

                {/* AI Mic Recording Button */}
                <button
                  onClick={handleStartMic}
                  disabled={isRecording}
                  className={`w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-8 py-3.5 rounded-2xl font-black text-sm text-white shadow-lg transition-all cursor-pointer ${
                    isRecording
                      ? 'bg-rose-500 animate-pulse'
                      : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 shadow-amber-500/30'
                  }`}
                >
                  <Mic className={`w-5 h-5 ${isRecording ? 'animate-bounce' : ''}`} />
                  <span>{isRecording ? 'Bibo đang lắng nghe bé nói...' : 'Bé bấm vào đây để nói'}</span>
                </button>

                {/* Next Word Button */}
                <button
                  onClick={() => {
                    const nextIndex = (currentWordIndex + 1) % currentBook.sampleUnit.targetVocab.length;
                    setCurrentWordIndex(nextIndex);
                    setIsFlipped(false);
                    setSpeechResult(null);
                  }}
                  className="w-full sm:w-auto inline-flex items-center justify-center space-x-1 px-4 py-3 rounded-2xl font-semibold text-xs text-slate-600 hover:bg-slate-100 border border-slate-200 transition-all cursor-pointer"
                >
                  <span>Từ tiếp theo</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* AI Phoneme Evaluation Result Box */}
              {speechResult && (
                <div className="mt-8 p-6 bg-slate-50 border-2 border-amber-300/80 rounded-2xl animate-fadeIn">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
                    <div className="flex items-center space-x-2">
                      <Sparkles className="w-5 h-5 text-amber-600" />
                      <span className="font-extrabold text-slate-900 text-sm">
                        Kết quả Chấm điểm AI Phoneme-level
                      </span>
                    </div>
                    <span className={`text-sm font-black px-3 py-1 rounded-xl ${
                      speechResult.score >= 80 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {speechResult.score} / 100 Điểm
                    </span>
                  </div>

                  {/* Phoneme Breakdown Pills */}
                  <div className="flex items-center justify-center space-x-2 mb-4">
                    {speechResult.phonemes.map((p, idx) => (
                      <div
                        key={idx}
                        className={`px-4 py-2 rounded-xl text-center border-2 font-bold cursor-pointer transition-transform hover:scale-105 ${
                          p.status === 'green'
                            ? 'bg-emerald-50 border-emerald-400 text-emerald-800'
                            : p.status === 'yellow'
                            ? 'bg-amber-50 border-amber-400 text-amber-800'
                            : 'bg-rose-50 border-rose-400 text-rose-800 animate-pulse'
                        }`}
                        onClick={() => playNativeAudio(p.phoneme)}
                        title="Bấm để nghe riêng âm này"
                      >
                        <span className="text-base block">{p.phoneme}</span>
                        <span className="text-[10px] font-mono">{p.score}%</span>
                      </div>
                    ))}
                  </div>

                  {/* Legend & Feedback */}
                  <div className="flex items-center justify-center space-x-4 text-[11px] text-slate-500 mb-2">
                    <span className="flex items-center"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500 mr-1" /> Xanh (Chuẩn ≥85%)</span>
                    <span className="flex items-center"><span className="w-2.5 h-2.5 rounded-full bg-amber-500 mr-1" /> Vàng (Tạm được 65-84%)</span>
                    <span className="flex items-center"><span className="w-2.5 h-2.5 rounded-full bg-rose-500 mr-1" /> Đỏ (&lt;65% - Cần uốn lưỡi)</span>
                  </div>

                  <p className="text-center text-xs font-bold text-slate-800 pt-2 border-t border-slate-200">
                    💡 {speechResult.feedback}
                  </p>
                </div>
              )}
            </div>

            {/* Conversation Dialogue Sample */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
              <h4 className="font-extrabold text-slate-900 text-sm mb-3 flex items-center">
                <span>💬 Luyện hội thoại Role-play SGK: {currentBook.sampleUnit.title}</span>
              </h4>
              <div className="space-y-3">
                {currentBook.sampleUnit.sampleConversation.map((chat, idx) => (
                  <div key={idx} className="flex items-start space-x-3 p-3 rounded-2xl bg-slate-50 border border-slate-100">
                    <div className="w-8 h-8 rounded-full bg-amber-200 text-amber-900 font-bold flex items-center justify-center text-xs shrink-0">
                      {chat.speaker.charAt(0)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs">{chat.speaker}:</span>
                        <button
                          onClick={() => playNativeAudio(chat.text)}
                          className="text-[11px] text-amber-600 hover:text-amber-800 font-bold flex items-center cursor-pointer"
                        >
                          <Volume2 className="w-3.5 h-3.5 mr-0.5" /> Nghe
                        </button>
                      </div>
                      <p className="text-xs font-semibold text-slate-800">{chat.text}</p>
                      <p className="text-[11px] text-slate-500 italic">{chat.vn}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Mascot & Gamification Sidebar */}
          <div className="lg:col-span-4 space-y-6">
            {/* Mascot Bibo Card */}
            <div className="bg-gradient-to-b from-amber-50 to-white rounded-3xl p-6 border-2 border-amber-200 text-center shadow-xs">
              <div className="text-6xl mb-2 animate-bounce">
                {mascotMood === 'cheer' ? '🐶🎉' : mascotMood === 'thinking' ? '🐶🤔' : '🐶'}
              </div>
              <h4 className="font-black text-slate-900 text-lg">Cún Bibo</h4>
              <p className="text-xs text-slate-500 font-medium mb-4">Bạn đồng hành Lớp 4</p>
              
              <div className="p-3 bg-amber-100/60 rounded-2xl border border-amber-200 text-xs text-amber-950 font-semibold mb-4">
                {mascotMood === 'cheer' 
                  ? '"Oa! Bé phát âm hay quá, Bibo tặng bé 3 Ngôi Sao nè!"'
                  : mascotMood === 'thinking'
                  ? '"Bibo đang nghe bé đọc, bé nói to và rõ nhé..."'
                  : '"Chào Khôi! Hôm nay chúng mình học Unit 1 để chuẩn bị cho bài kiểm tra 15 phút nhé!"'
                }
              </div>

              {/* Kid Avatar Shop Preview */}
              <div className="pt-3 border-t border-slate-200">
                <span className="text-[11px] font-bold text-slate-700 block mb-2">Tủ đồ ảo của Bibo (Đổi bằng Kim Cương)</span>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="p-2 rounded-xl bg-white border border-slate-200 text-center">
                    <span className="text-2xl block mb-1">🎓</span>
                    <span className="text-[10px] text-slate-600 font-bold">Mũ tiến sĩ</span>
                  </div>
                  <div className="p-2 rounded-xl bg-white border border-slate-200 text-center">
                    <span className="text-2xl block mb-1">🕶️</span>
                    <span className="text-[10px] text-slate-600 font-bold">Kính râm</span>
                  </div>
                  <div className="p-2 rounded-xl bg-white border border-slate-200 text-center">
                    <span className="text-2xl block mb-1">🎒</span>
                    <span className="text-[10px] text-slate-600 font-bold">Ba lô siêu nhân</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Daily Goal Card */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <span className="font-bold text-xs text-slate-700">Mục tiêu hôm nay: 20 phút</span>
                <span className="text-xs font-bold text-amber-600">18 / 20m</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-3 mb-2 overflow-hidden">
                <div className="bg-gradient-to-r from-amber-500 to-orange-500 h-3 rounded-full" style={{ width: '90%' }} />
              </div>
              <p className="text-[11px] text-slate-500">
                Chỉ còn 2 phút nữa là hoàn thành mục tiêu ngày và bảo vệ ngọn lửa Streak 🔥
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* MODE 2: PARENT ZONE & ZALO OA SIMULATOR */
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Parental Gate Check */}
          {isParentGateLocked ? (
            <div className="bg-white rounded-3xl p-8 border-2 border-sky-300 shadow-lg text-center max-w-md mx-auto">
              <div className="w-14 h-14 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center mx-auto mb-4 font-bold">
                <Lock className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-extrabold text-slate-900 mb-2">
                Cổng Bảo Vệ Phụ Huynh (Parental Gate)
              </h3>
              <p className="text-xs text-slate-600 mb-6">
                Để bảo vệ quyền riêng tư và ví tiền của bạn, vui lòng hoàn thành phép tính dưới đây để xác nhận bạn là người lớn:
              </p>

              <form onSubmit={handleParentGateSubmit} className="space-y-4">
                <div className="p-4 bg-sky-50 rounded-2xl border border-sky-200 font-mono text-2xl font-black text-sky-900 tracking-wider">
                  7 × 8 = ?
                </div>

                <input
                  type="number"
                  placeholder="Nhập kết quả..."
                  value={parentMathAnswer}
                  onChange={(e) => setParentMathAnswer(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 text-center font-bold text-lg focus:outline-hidden focus:border-sky-500"
                  autoFocus
                />

                {parentGateError && (
                  <p className="text-xs font-bold text-rose-600">
                    Kết quả chưa đúng! Vui lòng thử lại (Gợi ý: 56).
                  </p>
                )}

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-sm shadow-md shadow-sky-600/20 cursor-pointer"
                >
                  Mở Khóa Khu Vực Phụ Huynh
                </button>
              </form>
            </div>
          ) : (
            /* Unlocked Parent Dashboard */
            <div className="space-y-8">
              {/* Parent Dashboard Top Banner */}
              <div className="bg-gradient-to-r from-sky-700 to-indigo-800 rounded-3xl p-6 sm:p-8 text-white shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-white/10 text-sky-200 text-xs font-semibold mb-2">
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>Parental Gate: Đã mở khóa an toàn</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-extrabold">
                    Hồ sơ học tập: Bé Nguyễn Minh Khôi (Lớp 4A)
                  </h3>
                  <p className="text-sky-200 text-xs mt-1">
                    Chương trình đang học: <strong>Global Success 4</strong> • Số điện thoại phụ huynh: <strong>098***1609</strong>
                  </p>
                </div>

                <div className="flex space-x-2">
                  <button
                    onClick={() => setShowVipModal(true)}
                    className="px-4 py-2.5 rounded-xl font-bold text-xs bg-amber-400 hover:bg-amber-300 text-amber-950 shadow-md cursor-pointer flex items-center space-x-1.5"
                  >
                    <Gift className="w-4 h-4" />
                    <span>Nâng cấp VIP</span>
                  </button>
                  <button
                    onClick={() => setIsParentGateLocked(true)}
                    className="px-3 py-2.5 rounded-xl font-bold text-xs bg-white/15 hover:bg-white/20 text-white cursor-pointer"
                  >
                    Khóa lại 🔒
                  </button>
                </div>
              </div>

              {/* Weekly Analytics Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[11px] text-slate-500 font-semibold block mb-1">Thời gian học tuần này</span>
                  <span className="text-2xl font-black text-slate-900">115 phút</span>
                  <span className="text-[10px] text-emerald-600 font-bold block mt-1">Đạt 115% kế hoạch</span>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[11px] text-slate-500 font-semibold block mb-1">Từ vựng đã thuộc</span>
                  <span className="text-2xl font-black text-slate-900">32 / 40 từ</span>
                  <span className="text-[10px] text-emerald-600 font-bold block mt-1">Khớp Unit 1 & Unit 2</span>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[11px] text-slate-500 font-semibold block mb-1">Điểm phát âm AI TB</span>
                  <span className="text-2xl font-black text-emerald-600">86 / 100</span>
                  <span className="text-[10px] text-slate-500 font-medium block mt-1">Tăng +8 điểm so với tuần trước</span>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[11px] text-slate-500 font-semibold block mb-1">Bảo vệ mắt 20-20-20</span>
                  <span className="text-2xl font-black text-sky-600">Bật</span>
                  <span className="text-[10px] text-slate-500 font-medium block mt-1">Nhắc nghỉ sau mỗi 20 phút</span>
                </div>
              </div>

              {/* Zalo OA Notification Card Simulator */}
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-3 mb-6">
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-base flex items-center">
                      <Smartphone className="w-5 h-5 text-sky-600 mr-2" />
                      Mô phỏng Báo Cáo Học Tập Gửi Qua Zalo Official Account (ZNS)
                    </h4>
                    <p className="text-xs text-slate-500">
                      Tự động gửi vào lúc 20:00 tối Chủ Nhật tới số Zalo của phụ huynh.
                    </p>
                  </div>

                  <button
                    onClick={handleSendZaloDigest}
                    className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl font-bold text-xs bg-sky-600 hover:bg-sky-700 text-white cursor-pointer shadow-sm shadow-sky-600/20"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Bấm gửi thử tin Zalo ngay</span>
                  </button>
                </div>

                {zaloSent && (
                  <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Đã gửi thành công tin nhắn mẫu qua Zalo OA EduKids tới số 098***1609!</span>
                  </div>
                )}

                {/* Zalo Message Preview Card */}
                <div className="max-w-md mx-auto bg-slate-100 p-4 rounded-3xl border border-slate-300">
                  <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200 text-xs space-y-3">
                    <div className="flex items-center space-x-2 pb-2 border-b border-slate-100">
                      <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
                        Z
                      </div>
                      <div>
                        <span className="font-bold text-slate-900 block text-xs">EduKids English 4 (Zalo OA Verified)</span>
                        <span className="text-[10px] text-slate-400">Hôm nay lúc 20:00</span>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-slate-700">
                      <p className="font-bold text-slate-900">
                        🔔 [BÁO CÁO TUẦN] Bé Minh Khôi đã hoàn thành xuất sắc tuần học!
                      </p>
                      <p>Kính gửi chị Thu Hương, EduKids gửi chị kết quả học của bé tuần từ 05/11 - 12/11:</p>
                      <ul className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1 font-medium text-[11px]">
                        <li>⏱️ <strong>Thời gian học:</strong> 115 phút (Đạt mục tiêu)</li>
                        <li>📚 <strong>Bài học:</strong> Unit 1 - My Friends (Global Success)</li>
                        <li>🎯 <strong>Phát âm chuẩn:</strong> 86/100 điểm</li>
                        <li>⚠️ <strong>Âm cần phụ đạo:</strong> Âm đuôi /s/ trong từ "Australia"</li>
                      </ul>
                    </div>

                    <div className="pt-2">
                      <button className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs text-center cursor-pointer">
                        Mở bài ôn tập 5 phút cho bé &rarr;
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Screen Time & Eye Protection Settings */}
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
                <h4 className="font-extrabold text-slate-900 text-sm mb-4 flex items-center">
                  <Eye className="w-4 h-4 text-sky-600 mr-2" />
                  Cài đặt Bảo vệ Mắt & Giới hạn Thời gian học mỗi ngày
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                    <span className="font-bold text-slate-900 block mb-1">Giới hạn thời gian màn hình:</span>
                    <p className="text-slate-500 mb-3">Sau thời gian này, app tự khóa chuyển sang màn hình Mascot nghỉ ngơi.</p>
                    <div className="flex space-x-2">
                      {[15, 20, 30, 45].map((mins) => (
                        <button
                          key={mins}
                          onClick={() => setScreenLimit(mins)}
                          className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer ${
                            screenLimit === mins
                              ? 'bg-sky-600 text-white'
                              : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          {mins} phút
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                    <span className="font-bold text-slate-900 block mb-1">Quy tắc nghỉ mắt 20-20-20:</span>
                    <p className="text-slate-500 mb-3">Cứ sau 20 phút học, nhắc nhở bé chớp mắt và nhìn ra xa 20 feet trong 20 giây.</p>
                    <span className="inline-flex items-center text-emerald-700 font-bold bg-emerald-100 px-2.5 py-1 rounded-full text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Đang kích hoạt tự động
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* VIP Upgrade Checkout Modal */}
      {showVipModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded-md text-xs font-black bg-amber-100 text-amber-900">VIP PASS</span>
                <h3 className="text-lg font-black text-slate-900">Nâng Cấp Gói Học Không Giới Hạn</h3>
              </div>
              <button
                onClick={() => setShowVipModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="py-4 space-y-4 text-xs">
              {/* Plan Picker */}
              <div className="grid grid-cols-2 gap-3">
                <div
                  onClick={() => setSelectedVipPlan('6m')}
                  className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                    selectedVipPlan === '6m'
                      ? 'border-amber-500 bg-amber-50/50'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <span className="font-bold text-slate-900 block text-sm">Gói 6 Tháng</span>
                  <span className="text-xl font-black text-amber-700 block my-1">590,000 đ</span>
                  <span className="text-[10px] text-slate-500">~3,200 đ/ngày</span>
                </div>

                <div
                  onClick={() => setSelectedVipPlan('1y')}
                  className={`p-4 rounded-2xl border-2 cursor-pointer relative transition-all ${
                    selectedVipPlan === '1y'
                      ? 'border-amber-500 bg-amber-50/50'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <span className="absolute -top-2.5 right-3 bg-rose-500 text-white font-black text-[10px] px-2 py-0.5 rounded-full">
                    TIẾT KIỆM 40%
                  </span>
                  <span className="font-bold text-slate-900 block text-sm">Gói 1 Năm (Khuyên dùng)</span>
                  <span className="text-xl font-black text-amber-700 block my-1">890,000 đ</span>
                  <span className="text-[10px] text-slate-500">Chỉ ~2,400 đ/ngày • Tặng Ebook SGK</span>
                </div>
              </div>

              {/* VietQR Payment Preview */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                <span className="font-bold text-slate-900 block mb-2">Thanh toán tức thì bằng Quét Mã QR Ngân hàng (VietQR)</span>
                <div className="w-36 h-36 mx-auto bg-white p-2 rounded-xl border border-slate-300 shadow-2xs flex items-center justify-center">
                  <QrCode className="w-28 h-28 text-slate-800" />
                </div>
                <p className="text-[11px] text-slate-500 mt-2">
                  Ngân hàng: <strong>MBBank</strong> • STK: <strong>098***1609</strong> • Số tiền: <strong>{selectedVipPlan === '1y' ? '890,000 VND' : '590,000 VND'}</strong>
                </p>
                <p className="text-[10px] text-emerald-700 font-bold mt-1">
                  ⚡ Webhook tự động kích hoạt tài khoản trong 5 giây sau khi chuyển khoản
                </p>
              </div>

              {/* Guarantee */}
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Cam kết hoàn tiền 100% trong 7 ngày nếu bé không tiến bộ hoặc không thích học.</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
              <span className="text-xs text-slate-500 font-medium">An toàn & Không tự động trừ tiền</span>
              <button
                onClick={() => {
                  alert('Mô phỏng thanh toán VietQR thành công! Tài khoản VIP của bé Minh Khôi đã được kích hoạt 1 năm.');
                  setShowVipModal(false);
                }}
                className="px-5 py-2.5 rounded-xl font-bold text-xs bg-amber-500 hover:bg-amber-600 text-white cursor-pointer shadow-md"
              >
                Xác nhận đã chuyển khoản
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
