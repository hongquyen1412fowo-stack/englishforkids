import React from 'react';
import { 
  Cpu, 
  Layers, 
  Database, 
  Zap, 
  ShieldCheck, 
  Cloud, 
  Smartphone, 
  Radio, 
  FileCode,
  Clock,
  Server
} from 'lucide-react';

export const ArchitectureView: React.FC = () => {
  const latencySteps = [
    { step: '1. Thu âm & Nén âm thanh Client', time: '200 ms', note: 'Opus 24kHz nén tại thiết bị trẻ em qua AudioWorklet' },
    { step: '2. VAD (Voice Activity Detection)', time: '150 ms', note: 'Phát hiện chính xác thời điểm bé dứt tiếng nói' },
    { step: '3. Mô hình ASR nhận diện âm học', time: '650 ms', note: 'Mô hình Conformer/Whisper fine-tune giọng trẻ em VN' },
    { step: '4. Forced Alignment & Chấm Phonemes', time: '350 ms', note: 'Đối sánh âm vị với từ điển phát âm chuẩn SGK' },
    { step: '5. Đóng gói JSON & Phản hồi UI', time: '200 ms', note: 'Gửi kết quả màu Xanh/Vàng/Đỏ và render giao diện' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-200 gap-4 mb-6">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800">
              System Architecture & AI Pipeline
            </span>
            <span className="text-xs text-slate-500 font-medium">Bản vẽ thiết kế kỹ thuật</span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 mt-1">
            Kiến Trúc Hệ Thống & Pipeline AI Luyện Phát Âm
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Mô hình phân tầng bảo mật, kiến trúc Headless CMS cho học liệu SGK và quy trình tối ưu độ trễ xử lý âm thanh dưới 1.8 giây.
          </p>
        </div>
      </div>

      {/* System Architecture Block Diagram */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs mb-8">
        <h3 className="font-extrabold text-slate-900 text-base mb-6 flex items-center">
          <Layers className="w-5 h-5 text-indigo-600 mr-2" />
          Sơ đồ Kiến Trúc Đa Tầng (Multi-Tier Architecture Diagram)
        </h3>

        <div className="space-y-4 text-xs">
          {/* Tier 1: Client Layer */}
          <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-amber-900 flex items-center text-sm">
                <Smartphone className="w-4 h-4 mr-1.5 text-amber-600" />
                1. Tầng Thiết Bị Khách (Client Apps - iOS, Android & Web Tablet)
              </span>
              <span className="text-[11px] font-mono font-bold text-amber-800 bg-amber-200/60 px-2 py-0.5 rounded-md">
                Cross-platform Flutter / React Native
              </span>
            </div>
            <p className="text-slate-600 mb-2">
              UI/UX thân thiện cho trẻ 9-10 tuổi (Nút bấm lớn 44px, gamification 60fps). Tích hợp AudioWorklet WebRTC để thu âm giọng nói mượt mà, bộ đệm Offline Storage (SQLite/WatermelonDB) cho phép học khi không có internet.
            </p>
          </div>

          {/* Tier 2: API Gateway & CDN */}
          <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-indigo-900 flex items-center text-sm">
                <Cloud className="w-4 h-4 mr-1.5 text-indigo-600" />
                2. Tầng Cổng Kết Nối & Mạng Phân Phối (API Gateway & Global CDN)
              </span>
              <span className="text-[11px] font-mono font-bold text-indigo-800 bg-indigo-200/60 px-2 py-0.5 rounded-md">
                Cloudflare Edge + Node.js Gateway
              </span>
            </div>
            <p className="text-slate-600 mb-2">
              Cloudflare CDN phân phối 100% tài nguyên audio bài nghe SGK và hình ảnh tranh vẽ minh họa với độ trễ &lt; 30ms tại Hà Nội & TP.HCM. API Gateway quản lý phân quyền Phụ huynh (Parental Gate) và Học sinh.
            </p>
          </div>

          {/* Tier 3: Microservices & Core Engines */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="font-bold text-slate-900 block mb-1 flex items-center">
                <Radio className="w-3.5 h-3.5 text-purple-600 mr-1" />
                AI Speech Engine (gRPC)
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                ASR Acoustic Alignment Server phân tích ngữ âm, tách từng âm tiết (Phoneme) và chấm điểm màu Xanh/Vàng/Đỏ trong 1.55s.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="font-bold text-slate-900 block mb-1 flex items-center">
                <Zap className="w-3.5 h-3.5 text-amber-600 mr-1" />
                Gamification & Streak Engine
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Redis In-memory quản lý bảng xếp hạng bạn bè đồng trang lứa và kiểm tra chuỗi ngày học liên tục múi giờ GMT+7 lúc 00:00.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="font-bold text-slate-900 block mb-1 flex items-center">
                <Server className="w-3.5 h-3.5 text-sky-600 mr-1" />
                Zalo OA & Payment Webhooks
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Xử lý webhook thanh toán VietQR ngân hàng, MoMo và tự động đẩy tin nhắn ZNS báo cáo tuần lúc 20:00 Chủ Nhật.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Latency Waterfall Breakdown */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-2 mb-6">
          <div>
            <h3 className="font-extrabold text-slate-900 text-base flex items-center">
              <Clock className="w-5 h-5 text-emerald-600 mr-2" />
              Chi Tiết Ngân Sách Độ Trễ AI (Speech Latency Budget Waterfall)
            </h3>
            <p className="text-xs text-slate-500">
              Mục tiêu cam kết P95 &lt; 1,800 ms — Thời gian thực tế đo kiểm: 1,550 ms.
            </p>
          </div>
          <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 font-extrabold text-xs">
            Đạt chuẩn phản hồi trẻ em (&lt; 2s)
          </span>
        </div>

        <div className="space-y-3 text-xs">
          {latencySteps.map((s, idx) => (
            <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center space-x-2">
                <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 font-bold flex items-center justify-center text-[10px]">
                  {idx + 1}
                </span>
                <span className="font-bold text-slate-800">{s.step}</span>
              </div>
              <div className="flex items-center space-x-3 text-slate-500">
                <span className="italic text-[11px]">{s.note}</span>
                <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                  {s.time}
                </span>
              </div>
            </div>
          ))}

          <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl flex items-center justify-between font-bold text-emerald-950 text-xs mt-4">
            <span>Tổng thời gian phản hồi toàn trình (End-to-End P95 Latency):</span>
            <span className="text-base font-black text-emerald-800 font-mono">1,550 ms (An toàn &lt; 1,800 ms)</span>
          </div>
        </div>
      </div>

      {/* Core Database Schema Reference */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <h3 className="font-extrabold text-slate-900 text-base mb-4 flex items-center">
          <Database className="w-5 h-5 text-amber-600 mr-2" />
          Mô hình Dữ Liệu Thực Thể Cốt Lõi (Entity Relational Schema)
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-2 font-sans text-xs">📁 Users (Phụ huynh)</span>
            <ul className="space-y-1 text-slate-600 text-[11px]">
              <li>- id: UUID (PK)</li>
              <li>- phone_number: String (Indexed)</li>
              <li>- zalo_user_id: String?</li>
              <li>- subscription_tier: 'FREE' | 'VIP'</li>
              <li>- vip_expired_at: Timestamp?</li>
              <li>- parent_pin_hash: String</li>
            </ul>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-2 font-sans text-xs">👦 Kids (Học sinh lớp 4)</span>
            <ul className="space-y-1 text-slate-600 text-[11px]">
              <li>- id: UUID (PK)</li>
              <li>- parent_id: UUID (FK)</li>
              <li>- nickname: String</li>
              <li>- current_curriculum: Enum</li>
              <li>- streak_count: Int</li>
              <li>- stars_total: Int</li>
              <li>- diamonds_total: Int</li>
              <li>- max_daily_minutes: Int (20)</li>
            </ul>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <span className="font-bold text-slate-900 block mb-2 font-sans text-xs">🎙️ Speech_Audits (AI Logs)</span>
            <ul className="space-y-1 text-slate-600 text-[11px]">
              <li>- id: UUID (PK)</li>
              <li>- kid_id: UUID (FK)</li>
              <li>- target_word: String</li>
              <li>- phoneme_scores: JSONB</li>
              <li>- total_score: Int</li>
              <li>- weak_phonemes: Array</li>
              <li>- created_at: Timestamp</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
