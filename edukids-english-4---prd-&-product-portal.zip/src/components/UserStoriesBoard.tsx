import React, { useState } from 'react';
import { USER_STORIES_BACKLOG } from '../data/userStories';
import { UserStory } from '../types/prd';
import { 
  CheckSquare, 
  Filter, 
  Search, 
  Layers, 
  Tag, 
  Clock, 
  ChevronRight, 
  CheckCircle2, 
  FileCode2,
  Table,
  LayoutGrid
} from 'lucide-react';

export const UserStoriesBoard: React.FC = () => {
  const [selectedModule, setSelectedModule] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [selectedPhase, setSelectedPhase] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');
  const [activeStory, setActiveStory] = useState<UserStory | null>(null);

  const modules = Array.from(new Set(USER_STORIES_BACKLOG.map(s => s.module)));

  const filteredStories = USER_STORIES_BACKLOG.filter(story => {
    const matchesModule = selectedModule === 'all' || story.module === selectedModule;
    const matchesPriority = selectedPriority === 'all' || story.priority === selectedPriority;
    const matchesPhase = selectedPhase === 'all' || story.phase === selectedPhase;
    const matchesSearch = searchQuery === '' || 
      story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      story.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      story.asA.toLowerCase().includes(searchQuery.toLowerCase()) ||
      story.iWantTo.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesModule && matchesPriority && matchesPhase && matchesSearch;
  });

  const totalPoints = filteredStories.reduce((acc, s) => acc + s.storyPoints, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Title & Stats */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-200 gap-4 mb-6">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
              Backlog & Acceptance Criteria
            </span>
            <span className="text-xs text-slate-500 font-medium">Sprint Ready</span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 mt-1">
            User Stories Ma Trận & Tiêu Chí Nghiệm Thu
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Được cấu trúc chuẩn xác theo định dạng <em>"As a... I want to... So that..."</em> kèm điều kiện nghiệm thu chi tiết cho Đội ngũ Kỹ thuật (Dev) và Thiết kế (UI/UX).
          </p>
        </div>

        {/* Stats Badges */}
        <div className="flex items-center space-x-3 shrink-0">
          <div className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-center shadow-2xs">
            <span className="block text-[11px] text-slate-500 font-medium">Tổng số Stories</span>
            <span className="font-extrabold text-lg text-slate-900">{filteredStories.length}</span>
          </div>
          <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-2 text-center shadow-2xs">
            <span className="block text-[11px] text-amber-800 font-medium">Tổng Story Points</span>
            <span className="font-extrabold text-lg text-amber-900">{totalPoints} pts</span>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs mb-6 space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Tìm theo ID (US-01), tiêu đề, vai trò, yêu cầu..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:outline-hidden focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
            />
          </div>

          {/* Module Filter */}
          <select
            value={selectedModule}
            onChange={(e) => setSelectedModule(e.target.value)}
            className="w-full sm:w-auto px-3 py-2 text-xs rounded-xl bg-slate-50 border border-slate-200 font-medium text-slate-700 cursor-pointer"
          >
            <option value="all">Tất cả Modules (M1 - M6)</option>
            {modules.map((m) => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>

          {/* Priority Filter */}
          <select
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
            className="w-full sm:w-auto px-3 py-2 text-xs rounded-xl bg-slate-50 border border-slate-200 font-medium text-slate-700 cursor-pointer"
          >
            <option value="all">Mọi độ ưu tiên (MoSCoW)</option>
            <option value="Must Have">Must Have (Bắt buộc MVP)</option>
            <option value="Should Have">Should Have (Cần có)</option>
            <option value="Could Have">Could Have (Nếu kịp)</option>
          </select>

          {/* Phase Filter */}
          <select
            value={selectedPhase}
            onChange={(e) => setSelectedPhase(e.target.value)}
            className="w-full sm:w-auto px-3 py-2 text-xs rounded-xl bg-slate-50 border border-slate-200 font-medium text-slate-700 cursor-pointer"
          >
            <option value="all">Tất cả giai đoạn</option>
            <option value="MVP (Giai đoạn 1)">MVP (Giai đoạn 1)</option>
            <option value="Phase 2 (Mở rộng)">Phase 2 (Mở rộng)</option>
          </select>

          {/* View Toggle */}
          <div className="flex items-center space-x-1 border border-slate-200 rounded-xl p-1 bg-slate-50 shrink-0">
            <button
              onClick={() => setViewMode('cards')}
              className={`p-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                viewMode === 'cards' ? 'bg-white shadow-2xs text-amber-600' : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Xem dạng thẻ"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                viewMode === 'table' ? 'bg-white shadow-2xs text-amber-600' : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Xem dạng bảng"
            >
              <Table className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Card Grid View */}
      {viewMode === 'cards' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredStories.map((story) => (
            <div
              key={story.id}
              onClick={() => setActiveStory(story)}
              className="bg-white rounded-2xl p-5 border border-slate-200 hover:border-amber-400 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-mono text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                      {story.id}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      story.priority === 'Must Have' 
                        ? 'bg-rose-100 text-rose-800' 
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {story.priority}
                    </span>
                  </div>
                  <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                    {story.storyPoints} pts
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-sm mb-2 group-hover:text-amber-700 transition-colors">
                  {story.title}
                </h3>

                <p className="text-[11px] text-slate-500 mb-3 font-medium">
                  {story.module} • {story.epic}
                </p>

                {/* As a / I want / So that */}
                <div className="space-y-1.5 text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 mb-3">
                  <p><strong className="text-slate-800">As a:</strong> {story.asA}</p>
                  <p><strong className="text-slate-800">I want to:</strong> {story.iWantTo}</p>
                  <p><strong className="text-slate-800">So that:</strong> {story.soThat}</p>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs text-slate-500 pt-3 border-t border-slate-100">
                  <span className="flex items-center text-emerald-700 font-semibold text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                    {story.acceptanceCriteria.length} Tiêu chí nghiệm thu
                  </span>
                  <span className="text-amber-600 font-bold flex items-center group-hover:translate-x-1 transition-transform">
                    Xem AC <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Table View */
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-100 text-slate-800 font-bold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">ID</th>
                  <th className="px-4 py-3">Tiêu đề User Story</th>
                  <th className="px-4 py-3">Module</th>
                  <th className="px-4 py-3">Ưu tiên</th>
                  <th className="px-4 py-3">Giai đoạn</th>
                  <th className="px-4 py-3">Points</th>
                  <th className="px-4 py-3">Chi tiết</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredStories.map((story) => (
                  <tr 
                    key={story.id} 
                    onClick={() => setActiveStory(story)}
                    className="hover:bg-amber-50/50 cursor-pointer transition-colors"
                  >
                    <td className="px-4 py-3 font-mono font-bold text-amber-700">
                      {story.id}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-900">
                      {story.title}
                    </td>
                    <td className="px-4 py-3 text-slate-600">
                      {story.module}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        story.priority === 'Must Have' 
                          ? 'bg-rose-100 text-rose-800' 
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {story.priority}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-600">
                      {story.phase}
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-800">
                      {story.storyPoints}
                    </td>
                    <td className="px-4 py-3 text-amber-600 font-bold">
                      Chi tiết &rarr;
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Story Detail Modal */}
      {activeStory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center space-x-2 mb-1">
                  <span className="font-mono text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                    {activeStory.id}
                  </span>
                  <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md">
                    {activeStory.priority}
                  </span>
                  <span className="text-xs font-medium text-slate-500">
                    {activeStory.phase} • {activeStory.storyPoints} Story Points
                  </span>
                </div>
                <h3 className="text-lg font-extrabold text-slate-900">
                  {activeStory.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveStory(null)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="py-4 space-y-4 text-xs">
              {/* As a / I want / So that */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <p><span className="font-bold text-slate-900">As a:</span> {activeStory.asA}</p>
                <p><span className="font-bold text-slate-900">I want to:</span> {activeStory.iWantTo}</p>
                <p><span className="font-bold text-slate-900">So that:</span> {activeStory.soThat}</p>
              </div>

              {/* Acceptance Criteria */}
              <div>
                <span className="font-bold text-sm text-slate-900 block mb-2 flex items-center">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mr-1.5" />
                  Tiêu chí nghiệm thu (Acceptance Criteria - Gherkin / Verification):
                </span>
                <div className="space-y-2">
                  {activeStory.acceptanceCriteria.map((ac, idx) => (
                    <div key={idx} className="flex items-start space-x-2.5 p-3 rounded-xl bg-emerald-50/50 border border-emerald-100">
                      <span className="w-5 h-5 rounded-full bg-emerald-200 text-emerald-800 font-bold flex items-center justify-center text-[11px] shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <p className="text-slate-700 leading-relaxed">{ac}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Technical Notes */}
              {activeStory.technicalNotes && (
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-950">
                  <span className="font-bold block mb-1 flex items-center">
                    <FileCode2 className="w-3.5 h-3.5 text-amber-600 mr-1" />
                    Ghi chú kỹ thuật cho Dev & Tester:
                  </span>
                  <p className="font-mono text-[11px]">{activeStory.technicalNotes}</p>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setActiveStory(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-900 text-white hover:bg-slate-800 cursor-pointer"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
