import React, { useState } from 'react';
import { 
  PRODUCT_META, 
  PERSONAS, 
  TEXTBOOKS, 
  PRD_RISKS, 
  KPI_METRICS 
} from '../data/prdContent';
import { 
  Target, 
  Users, 
  GitBranch, 
  Layers, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles,
  BookOpen, 
  Mic, 
  Award, 
  FileCheck, 
  Clock, 
  CreditCard,
  ChevronRight,
  Search,
  ExternalLink,
  MessageSquareQuote
} from 'lucide-react';

export const PrdDocumentView: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCurriculumTab, setSelectedCurriculumTab] = useState<'global-success' | 'family-friends' | 'smart-start'>('global-success');

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const yOffset = -80;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  const sectionsList = [
    { id: 'sec-overview', label: '1. Tổng quan sản phẩm & KPIs', icon: Target },
    { id: 'sec-personas', label: '2. Đối tượng & Chân dung khách hàng', icon: Users },
    { id: 'sec-user-flows', label: '3. Luồng người dùng chính (User Flows)', icon: GitBranch },
    { id: 'sec-functional', label: '4. Đặc tả tính năng chi tiết (M1 - M6)', icon: Layers },
    { id: 'sec-non-functional', label: '5. Yêu cầu phi chức năng & Bảo mật', icon: ShieldCheck },
    { id: 'sec-risks', label: '6. Quản trị rủi ro & Giải pháp', icon: AlertTriangle }
  ];

  const currentBook = TEXTBOOKS.find(b => b.id === selectedCurriculumTab) || TEXTBOOKS[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header Hero Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl relative overflow-hidden mb-8 border border-slate-800">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-4xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-semibold mb-4 border border-amber-400/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Tài liệu Yêu cầu Sản phẩm Cấp cao (Enterprise EdTech PRD)</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight mb-3">
            {PRODUCT_META.title} - Ứng Dụng Học Tiếng Anh Chuẩn SGK Lớp 4
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            Bản đặc tả sản phẩm bám sát 100% Chương trình Giáo dục Phổ thông 2018 (Thông tư 32/2018/TT-BGDĐT) 
            cùng 3 bộ sách giáo khoa trọng tâm: <span className="text-amber-300 font-semibold">Global Success</span>,{' '}
            <span className="text-amber-300 font-semibold">Family and Friends National Edition</span>, và{' '}
            <span className="text-amber-300 font-semibold">i-Learn Smart Start Grade 4</span>.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-800 text-xs">
            <div>
              <span className="text-slate-400 block font-medium">Tác giả PRD:</span>
              <span className="font-semibold text-slate-100">{PRODUCT_META.author}</span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Đối tượng mục tiêu:</span>
              <span className="font-semibold text-slate-100">{PRODUCT_META.targetSegment}</span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Phiên bản tài liệu:</span>
              <span className="font-semibold text-amber-400 font-mono">{PRODUCT_META.version}</span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Tình trạng:</span>
              <span className="font-semibold text-emerald-400 flex items-center space-x-1">
                <CheckCircle2 className="w-3.5 h-3.5 inline mr-1" />
                {PRODUCT_META.status}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Layout: Sticky TOC + Document Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Sticky Sidebar (Table of Contents) */}
        <div className="hidden lg:block lg:col-span-3">
          <div className="sticky top-24 bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Mục lục tài liệu
              </span>
              <span className="text-[11px] text-slate-400 font-medium">6 Phần chính</span>
            </div>

            {/* Quick Search in PRD */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Tìm kiếm nội dung..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg bg-slate-50 border border-slate-200 focus:outline-hidden focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <nav className="space-y-1">
              {sectionsList.map((sec) => {
                const Icon = sec.icon;
                return (
                  <button
                    key={sec.id}
                    onClick={() => scrollToSection(sec.id)}
                    className="w-full flex items-center space-x-2.5 px-3 py-2 text-xs font-semibold text-slate-600 hover:text-amber-700 hover:bg-amber-50/70 rounded-xl transition-colors text-left group cursor-pointer"
                  >
                    <Icon className="w-4 h-4 text-slate-400 group-hover:text-amber-600 shrink-0" />
                    <span className="truncate">{sec.label}</span>
                  </button>
                );
              })}
            </nav>

            <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200/60 text-xs text-amber-900">
              <span className="font-bold block mb-1">💡 Senior PM Advice:</span>
              Học sinh lớp 4 (9 tuổi) đang ở bước chuyển từ chơi sang học có hệ thống. Trọng tâm là 
              <strong> 100% bám sát bài kiểm tra định kỳ ở trường</strong> để phụ huynh nhận thấy giá trị hữu hình ngay sau 2 tuần.
            </div>
          </div>
        </div>

        {/* Right Content Column */}
        <div className="lg:col-span-9 space-y-12">
          
          {/* SECTION 1: Tổng quan sản phẩm */}
          <section id="sec-overview" className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs">
            <div className="flex items-center space-x-3 mb-6 pb-4 border-b border-slate-100">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                <Target className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-amber-700">Phần 1</span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                  Tổng quan sản phẩm (Product Overview)
                </h2>
              </div>
            </div>

            {/* Vision & Goals */}
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 mb-2 flex items-center">
                  <span className="w-2 h-2 rounded-full bg-amber-500 mr-2" />
                  1.1. Tầm nhìn & Mục tiêu sản phẩm (Vision & Goals)
                </h3>
                <p className="text-slate-700 text-sm leading-relaxed mb-4">
                  <strong>Tầm nhìn (Vision):</strong> Trở thành <em>"Gia sư số tiếng Anh bám sát SGK thông minh và gần gũi nhất"</em> 
                  cho hơn 1.8 triệu học sinh lớp 4 tại Việt Nam, biến việc học tiếng Anh trên trường từ áp lực điểm số thành hành trình 
                  khám phá tự giác, giúp trẻ tự tin phát âm chuẩn và phụ huynh hoàn toàn an tâm dù không biết ngoại ngữ.
                </p>

                {/* Problem Statement Table */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
                  <div className="bg-rose-50/60 border border-rose-200/70 rounded-2xl p-4">
                    <div className="flex items-center space-x-2 text-rose-800 font-bold text-sm mb-2">
                      <span className="text-base">🎒</span>
                      <span>Nỗi đau của Học sinh Lớp 4 (9-10 tuổi)</span>
                    </div>
                    <ul className="text-xs text-rose-900/90 space-y-2 list-disc pl-4 leading-relaxed">
                      <li><strong>Quá tải nội dung:</strong> Lớp 4 bắt đầu xuất hiện nhiều thì ngữ pháp (Hiện tại đơn, Tiếp diễn, Quá khứ đơn), từ vựng dài 3-4 âm tiết (Australia, Wednesday, Timetable) khiến trẻ dễ chán nản nếu học vẹt trên giấy.</li>
                      <li><strong>Nỗi sợ phát âm sai:</strong> Thiếu môi trường luyện phát âm cá nhân hóa, trẻ sợ bị thầy cô và bạn bè cười khi phát âm sai âm đuôi (/s/, /ʃ/, /tʃ/) hoặc trọng âm.</li>
                      <li><strong>Nguy cơ mất gốc từ lớp 3:</strong> Trẻ không nắm vững ngữ âm phonics căn bản dẫn đến không thể đọc và viết đúng chính tả các câu hỏi dài.</li>
                      <li><strong>Thiếu động lực tự giác:</strong> Trẻ thích chơi game hoạt hình hơn là ngồi làm các phiếu bài tập photocopy khô khan.</li>
                    </ul>
                  </div>

                  <div className="bg-sky-50/60 border border-sky-200/70 rounded-2xl p-4">
                    <div className="flex items-center space-x-2 text-sky-800 font-bold text-sm mb-2">
                      <span className="text-base">👩‍👧‍👦</span>
                      <span>Nỗi đau của Phụ huynh học sinh</span>
                    </div>
                    <ul className="text-xs text-sky-900/90 space-y-2 list-disc pl-4 leading-relaxed">
                      <li><strong>Bất lực vì không có trình độ/thời gian:</strong> Đa số phụ huynh thế hệ 8x, 9x phát âm tiếng Anh chưa chuẩn hoặc bận rộn kiếm sống, không thể ngồi sửa từng câu cho con.</li>
                      <li><strong>Áp lực kiểm tra định kỳ:</strong> Tiếng Anh lớp 4 là môn đánh giá bằng điểm số định kỳ (Giữa kỳ, Cuối kỳ) ghi vào học bạ tiểu học, phụ huynh rất lo con bị điểm kém.</li>
                      <li><strong>Bẫy nội dung số độc hại:</strong> Cho con mượn điện thoại để học thì con hay lướt sang YouTube Shorts, TikTok hoặc xem quảng cáo game bạo lực không kiểm soát.</li>
                      <li><strong>Trung tâm đắt đỏ, lệch giáo trình:</strong> Các khóa học trung tâm quốc tế học phí 15-30 triệu/năm nhưng dạy giáo trình riêng, con về trường thi SGK Bộ GD&ĐT điểm vẫn thấp.</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* KPIs & Metrics Table */}
              <div className="pt-4">
                <h3 className="text-base font-bold text-slate-900 mb-3 flex items-center">
                  <span className="w-2 h-2 rounded-full bg-amber-500 mr-2" />
                  1.2. Chỉ số đo lường thành công (Success Metrics / KPIs)
                </h3>
                <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                  <table className="w-full text-left text-xs text-slate-700">
                    <thead className="bg-slate-100 text-slate-800 font-bold uppercase tracking-wider border-b border-slate-200">
                      <tr>
                        <th className="px-4 py-3">Chỉ số cốt lõi (Metric)</th>
                        <th className="px-4 py-3">Mục tiêu (Target)</th>
                        <th className="px-4 py-3">Chuẩn ngành (Benchmark)</th>
                        <th className="px-4 py-3">Ý nghĩa chiến lược</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {KPI_METRICS.map((kpi) => (
                        <tr key={kpi.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="px-4 py-3 font-semibold text-slate-900">
                            {kpi.metric}
                          </td>
                          <td className="px-4 py-3 font-bold text-emerald-700 bg-emerald-50/50">
                            {kpi.target}
                          </td>
                          <td className="px-4 py-3 text-slate-600">
                            {kpi.benchmark}
                          </td>
                          <td className="px-4 py-3 text-slate-600">
                            {kpi.importance}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </section>

          {/* SECTION 2: Personas */}
          <section id="sec-personas" className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs">
            <div className="flex items-center space-x-3 mb-6 pb-4 border-b border-slate-100">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-700">Phần 2</span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                  Đối tượng người dùng & Chân dung khách hàng (Personas)
                </h2>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {PERSONAS.map((persona) => (
                <div 
                  key={persona.id}
                  className={`rounded-2xl p-5 border ${
                    persona.type === 'primary' 
                      ? 'bg-gradient-to-b from-amber-50/40 to-white border-amber-200' 
                      : 'bg-gradient-to-b from-sky-50/40 to-white border-sky-200'
                  }`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 rounded-2xl bg-white shadow-xs border border-slate-200 flex items-center justify-center text-2xl">
                        {persona.avatar}
                      </div>
                      <div>
                        <h4 className="font-extrabold text-slate-900 text-base">{persona.name}</h4>
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[11px] font-bold ${
                          persona.type === 'primary' ? 'bg-amber-100 text-amber-800' : 'bg-sky-100 text-sky-800'
                        }`}>
                          {persona.role}
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 mb-3 italic">
                    "{persona.bio}"
                  </p>

                  <div className="p-3 bg-white/80 rounded-xl border border-slate-200/60 mb-4">
                    <div className="flex items-center text-xs font-bold text-slate-800 mb-1">
                      <MessageSquareQuote className="w-3.5 h-3.5 text-amber-600 mr-1.5" />
                      <span>Câu nói tiêu biểu:</span>
                    </div>
                    <p className="text-xs text-slate-700 font-semibold italic">
                      {persona.quote}
                    </p>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div>
                      <span className="font-bold text-rose-700 block mb-1">Nỗi đau (Pain Points):</span>
                      <ul className="list-disc pl-4 space-y-1 text-slate-600">
                        {persona.painPoints.map((p, idx) => (
                          <li key={idx}>{p}</li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <span className="font-bold text-emerald-700 block mb-1">Mục tiêu (Goals):</span>
                      <ul className="list-disc pl-4 space-y-1 text-slate-600">
                        {persona.goals.map((g, idx) => (
                          <li key={idx}>{g}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* SECTION 3: User Flows */}
          <section id="sec-user-flows" className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs">
            <div className="flex items-center space-x-3 mb-6 pb-4 border-b border-slate-100">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                <GitBranch className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">Phần 3</span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                  Luồng người dùng chính (User Flows)
                </h2>
              </div>
            </div>

            <div className="space-y-8">
              {/* Flow 1: Onboarding */}
              <div className="border border-slate-200 rounded-2xl p-5 bg-slate-50/50">
                <div className="flex items-center space-x-2 text-slate-900 font-bold text-sm mb-3">
                  <span className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center text-xs">1</span>
                  <span>Luồng Onboarding (Lần đầu mở ứng dụng - Dành cho Phụ huynh & Bé)</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="font-bold text-amber-700 block mb-1">Bước 1: Đăng ký</span>
                    <p className="text-slate-600">Nhập SĐT phụ huynh -&gt; Nhận mã OTP qua Zalo/SMS trong 15s. Tự động liên kết Zalo ID.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="font-bold text-amber-700 block mb-1">Bước 2: Hồ sơ bé</span>
                    <p className="text-slate-600">Điền tên gọi ở nhà của bé (vd: Bắp), chọn Giới tính, chọn Mascot đồng hành (Cún Bibo / Mèo Mimi).</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="font-bold text-amber-700 block mb-1">Bước 3: Chọn SGK</span>
                    <p className="text-slate-600">Chọn 1 trong 3 bộ SGK: <em>Global Success</em>, <em>Family & Friends</em>, hoặc <em>i-Learn Smart Start</em>.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="font-bold text-amber-700 block mb-1">Bước 4: Test thử 3 phút</span>
                    <p className="text-slate-600">Bài kiểm tra ngắn 5 câu (tùy chọn) để gợi ý lộ trình ôn tập bắt đầu từ Unit 1 hoặc bài nâng cao.</p>
                  </div>
                </div>
              </div>

              {/* Flow 2: Core Learning Loop */}
              <div className="border border-amber-200 rounded-2xl p-5 bg-amber-50/30">
                <div className="flex items-center space-x-2 text-slate-900 font-bold text-sm mb-3">
                  <span className="w-6 h-6 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs">2</span>
                  <span>Luồng học tập cốt lõi (Core Learning Loop - Vòng lặp 15-20 phút/ngày)</span>
                </div>
                <p className="text-xs text-slate-600 mb-3">
                  Vòng lặp được thiết kế chuẩn sư phạm <strong>"Nghe - Hiểu - Luyện nói - Thực hành - Khắc sâu"</strong>, 
                  tối ưu hóa khoảng chú ý 15-20 phút của học sinh 9-10 tuổi:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 text-xs">
                  <div className="bg-white p-3 rounded-xl border border-amber-200 shadow-2xs">
                    <span className="font-bold text-amber-800 block mb-1">1. Khởi động (2m)</span>
                    <p className="text-slate-600">Mascot Bibo chào đón, nhắc nhở bài học Unit hôm nay theo SGK trên lớp.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-amber-200 shadow-2xs">
                    <span className="font-bold text-amber-800 block mb-1">2. Từ vựng (4m)</span>
                    <p className="text-slate-600">Lật Flashcard tương tác, nghe phát âm bản xứ, xem hình ảnh vẽ tay vui nhộn.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-amber-200 shadow-2xs">
                    <span className="font-bold text-amber-800 block mb-1">3. AI Luyện nói (6m)</span>
                    <p className="text-slate-600">Bấm micro, đọc từ vựng và câu mẫu. AI chấm điểm âm tiết Xanh / Vàng / Đỏ tức thì.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-amber-200 shadow-2xs">
                    <span className="font-bold text-amber-800 block mb-1">4. Game hóa (5m)</span>
                    <p className="text-slate-600">Đóng vai hội thoại (Role-play), kéo thả từ điền chỗ trống, giải cứu Mascot.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-amber-200 shadow-2xs">
                    <span className="font-bold text-amber-800 block mb-1">5. Phần thưởng (1m)</span>
                    <p className="text-slate-600">Nhận 3 Sao, Kim Cương thưởng, duy trì Streak, gửi thông báo hoàn thành tới Zalo phụ huynh.</p>
                  </div>
                </div>
              </div>

              {/* Flow 3: Parent Zone */}
              <div className="border border-sky-200 rounded-2xl p-5 bg-sky-50/30">
                <div className="flex items-center space-x-2 text-slate-900 font-bold text-sm mb-3">
                  <span className="w-6 h-6 rounded-full bg-sky-600 text-white flex items-center justify-center text-xs">3</span>
                  <span>Luồng Phụ huynh (Parent Zone & Parental Gate Flow)</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
                  <div className="bg-white p-3 rounded-xl border border-sky-200 shadow-2xs">
                    <span className="font-bold text-sky-800 block mb-1">1. Khóa Parental Gate</span>
                    <p className="text-slate-600">Giải phép tính nhân ngẫu nhiên (ví dụ: 6 × 9 = ?) hoặc nhập mã PIN 4 chữ số bí mật.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-sky-200 shadow-2xs">
                    <span className="font-bold text-sky-800 block mb-1">2. Báo cáo học tập</span>
                    <p className="text-slate-600">Biểu đồ thời gian học trong tuần, số từ đã thuộc, danh sách từ con hay phát âm sai.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-sky-200 shadow-2xs">
                    <span className="font-bold text-sky-800 block mb-1">3. Cài đặt an toàn</span>
                    <p className="text-slate-600">Bật giới hạn 20-30 phút/ngày, cấu hình nhận tin nhắn định kỳ qua Zalo Official Account.</p>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-sky-200 shadow-2xs">
                    <span className="font-bold text-sky-800 block mb-1">4. Nâng cấp VIP</span>
                    <p className="text-slate-600">Quét mã VietQR hoặc ví MoMo để kích hoạt tài khoản không giới hạn, kích hoạt tức thì.</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* SECTION 4: Functional Requirements */}
          <section id="sec-functional" className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs">
            <div className="flex items-center space-x-3 mb-6 pb-4 border-b border-slate-100">
              <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-purple-700">Phần 4</span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                  Đặc tả tính năng chi tiết (Functional Requirements)
                </h2>
              </div>
            </div>

            <p className="text-xs text-slate-600 mb-6">
              Hệ thống được chia thành <strong>6 Modules chức năng cốt lõi</strong>, phân kỳ phát triển rõ ràng 
              giữa <strong>MVP (Giai đoạn 1 - Launch thị trường trong 12 tuần)</strong> và <strong>Phase 2 (Mở rộng sau 6 tháng)</strong>:
            </p>

            {/* Curriculum Showcase Switcher */}
            <div className="mb-8 p-4 bg-slate-50 border border-slate-200 rounded-2xl">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center">
                  <BookOpen className="w-4 h-4 text-amber-600 mr-1.5" />
                  Đối chiếu Học liệu 3 Bộ Sách Giáo Khoa Lớp 4
                </span>
                <span className="text-[11px] text-slate-500">Khớp từng trang Lesson</span>
              </div>

              {/* Tabs */}
              <div className="flex space-x-2 border-b border-slate-200 pb-2 mb-4">
                {TEXTBOOKS.map((tb) => (
                  <button
                    key={tb.id}
                    onClick={() => setSelectedCurriculumTab(tb.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      selectedCurriculumTab === tb.id
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-white text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {tb.name}
                  </button>
                ))}
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-200 text-xs space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-2 border-b border-slate-100 gap-1">
                  <div>
                    <span className="font-bold text-slate-900 text-sm">{currentBook.name}</span>
                    <span className="text-slate-500 block text-[11px]">{currentBook.publisher}</span>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-semibold self-start sm:self-auto text-[11px]">
                    {currentBook.marketShare}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="font-bold text-amber-800 block mb-1">
                      {currentBook.sampleUnit.title}: {currentBook.sampleUnit.theme}
                    </span>
                    <span className="text-slate-500 block mb-2">Cấu trúc mẫu câu mục tiêu:</span>
                    <div className="p-2 bg-amber-50 rounded-lg font-mono text-amber-900 text-[11px] font-semibold border border-amber-200/60">
                      {currentBook.sampleUnit.targetSentence}
                    </div>
                  </div>

                  <div>
                    <span className="font-bold text-slate-700 block mb-1">Từ vựng & Phân tích âm tiết Phonemes:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {currentBook.sampleUnit.targetVocab.map((v, i) => (
                        <div key={i} className="px-2 py-1 bg-slate-100 rounded-md border border-slate-200 flex items-center space-x-1">
                          <span className="font-bold text-slate-800">{v.word}</span>
                          <span className="text-slate-500 text-[10px] font-mono">{v.ipa}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Modules Grid */}
            <div className="space-y-6">
              {/* Module 1 */}
              <div className="border border-slate-200 rounded-2xl p-5 hover:border-amber-300 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-slate-900 text-sm flex items-center">
                    <BookOpen className="w-4 h-4 text-amber-600 mr-2" />
                    Module 1: Hệ thống học liệu chuẩn SGK Lớp 4 (Curriculum Engine)
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                    MVP (Giai đoạn 1)
                  </span>
                </div>
                <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-5">
                  <li><strong>Số lượng Unit:</strong> Đóng gói đủ 20 Units (Global Success) hoặc 12 Units (Family & Friends), khớp từng Lesson 1 (Từ vựng & Cấu trúc), Lesson 2 (Hội thoại thực hành), Lesson 3 (Ngữ âm Phonics & Đọc hiểu).</li>
                  <li><strong>Chuyển đổi linh hoạt:</strong> Phụ huynh có thể đổi bộ sách bất cứ lúc nào trong Cài đặt mà không làm mất số sao hay chuỗi streak tích lũy.</li>
                  <li><strong>Chế độ song ngữ hỗ trợ:</strong> Mọi giải thích ngữ pháp đều có nút bấm nghe giải thích bằng tiếng Việt với giọng cô giáo bản địa miền Bắc/Nam truyền cảm.</li>
                </ul>
              </div>

              {/* Module 2 */}
              <div className="border border-slate-200 rounded-2xl p-5 hover:border-amber-300 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-slate-900 text-sm flex items-center">
                    <Mic className="w-4 h-4 text-amber-600 mr-2" />
                    Module 2: Công nghệ AI Luyện phát âm & Giao tiếp (AI Speech Recognition Engine)
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                    MVP (Giai đoạn 1)
                  </span>
                </div>
                <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-5">
                  <li><strong>Chấm điểm Phoneme-level:</strong> Phân tích từng âm vị (Phoneme) trong từ vựng và câu. Hiển thị màu sắc: 
                    <span className="text-emerald-600 font-bold ml-1">Xanh lá (≥85% - Chuẩn)</span>, 
                    <span className="text-amber-600 font-bold ml-1">Vàng (65-84% - Tạm được)</span>, 
                    <span className="text-rose-600 font-bold ml-1">Đỏ (&lt;65% - Cần uốn lưỡi)</span>.
                  </li>
                  <li><strong>Tập trung lỗi người Việt hay gặp:</strong> Bắt lỗi chuẩn xác âm đuôi <em>ending sounds</em> (/s/, /z/, /t/, /d/, /tʃ/) và trọng âm từ (stress syllables).</li>
                  <li><strong>Đóng vai hội thoại (Role-play with AI - Phase 2):</strong> Học sinh đối thoại thời gian thực cùng nhân vật hoạt hình Ben, Mai theo kịch bản bài học SGK, có AI hỗ trợ phát hiện ý nếu bé nói biến thể hợp lệ.</li>
                </ul>
              </div>

              {/* Module 3 */}
              <div className="border border-slate-200 rounded-2xl p-5 hover:border-amber-300 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-slate-900 text-sm flex items-center">
                    <Award className="w-4 h-4 text-amber-600 mr-2" />
                    Module 3: Hệ thống Game hóa (Gamification & Engagement Engine)
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                    MVP (Giai đoạn 1)
                  </span>
                </div>
                <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-5">
                  <li><strong>Mascot Đồng hành:</strong> Bé nuôi và tương tác với chú Cún Bibo thông minh; Bibo reo vui nhảy múa khi bé phát âm đúng và làm mặt phụng phịu khi bé nghỉ học 2 ngày.</li>
                  <li><strong>Chuỗi Streak & Rương thần:</strong> Duy trì học mỗi ngày tối thiểu 15 phút để thắp sáng Ngọn Lửa Streak. Streak 7 ngày nhận Rương báu mở vật phẩm hiếm.</li>
                  <li><strong>Bảng xếp hạng an toàn:</strong> Chia nhóm 30 bạn cùng hạng (Đồng, Bạc, Vàng). Tuyệt đối bảo mật danh tính, chỉ hiển thị Avatar hoạt hình và tên thân mật.</li>
                  <li><strong>Avatar Shop phi thương mại:</strong> Dùng Kim Cương tích lũy từ việc học để đổi phụ kiện nón, áo cho Mascot (không thể nạp tiền thật mua kim cương, bảo vệ tiền phụ huynh).</li>
                </ul>
              </div>

              {/* Module 4 */}
              <div className="border border-slate-200 rounded-2xl p-5 hover:border-amber-300 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-slate-900 text-sm flex items-center">
                    <FileCheck className="w-4 h-4 text-amber-600 mr-2" />
                    Module 4: Kho đề ôn thi Giữa kỳ & Cuối kỳ chuẩn Bộ GD&ĐT
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                    MVP (Giai đoạn 1)
                  </span>
                </div>
                <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-5">
                  <li><strong>Cấu trúc chuẩn đề thi:</strong> 10 đề Giữa kỳ 1, 10 đề Cuối kỳ 1, 10 đề Giữa kỳ 2, 10 đề Cuối kỳ 2 cho mỗi bộ SGK.</li>
                  <li><strong>Ma trận đề thi 3 kỹ năng:</strong> Listening (Nghe tranh, tích chọn A-B-C, điền từ vào chỗ trống), Reading (Đọc đoạn văn ngắn 50-80 từ và trả lời True/False), Writing (Sắp xếp lại trật tự từ thành câu đúng ngữ pháp).</li>
                  <li><strong>Chấm điểm & Lời giải tiếng Việt:</strong> Báo điểm ngay sau khi bấm Nộp bài; mỗi câu sai đều có video hoặc pop-up giải thích rõ vì sao chọn đáp án đó.</li>
                </ul>
              </div>

              {/* Module 5 */}
              <div className="border border-slate-200 rounded-2xl p-5 hover:border-amber-300 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-slate-900 text-sm flex items-center">
                    <Clock className="w-4 h-4 text-amber-600 mr-2" />
                    Module 5: Khu vực Phụ huynh (Parent Zone) & Tích hợp Zalo OA
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                    MVP (Giai đoạn 1)
                  </span>
                </div>
                <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-5">
                  <li><strong>Parental Gate:</strong> Khóa bảo vệ bằng phép toán nhân/chia ngẫu nhiên (ví dụ: 8 x 7 = 56) ngăn trẻ tự bấm vào khu vực nhạy cảm.</li>
                  <li><strong>Báo cáo tự động qua Zalo ZNS:</strong> 20:00 tối Chủ Nhật hàng tuần, Zalo OA tự động gửi tin nhắn mẫu đẹp cho phụ huynh: Tổng số phút học, số bài hoàn thành, các âm con cần ôn lại kèm nút bấm 1 chạm để mở bài tập phụ đạo.</li>
                  <li><strong>Bảo vệ mắt 20-20-20:</strong> Cứ sau 20 phút học liên tục, màn hình tạm thời khóa trong 20 giây hiển thị Mascot hướng dẫn bé nhìn xa ra cửa sổ để chống cận thị học đường.</li>
                </ul>
              </div>

              {/* Module 6 */}
              <div className="border border-slate-200 rounded-2xl p-5 hover:border-amber-300 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-slate-900 text-sm flex items-center">
                    <CreditCard className="w-4 h-4 text-amber-600 mr-2" />
                    Module 6: Hệ thống Thanh toán & Quản lý gói cước (Monetization Engine)
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                    MVP (Giai đoạn 1)
                  </span>
                </div>
                <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-5">
                  <li><strong>Mô hình Freemium:</strong> Cho học miễn phí trọn vẹn Unit 1 & Unit 2 + 1 đề thi thử + 5 lượt chấm phát âm AI mỗi ngày để phụ huynh kiểm chứng chất lượng.</li>
                  <li><strong>Gói cước VIP:</strong> 
                    Gói 6 Tháng (590,000 VND) và Gói 1 Năm (890,000 VND - Tương đương chỉ ~2,400 VND/ngày).
                  </li>
                  <li><strong>Cổng thanh toán bản địa hóa:</strong> Quét mã VietQR (tự điền số tiền và nội dung chuyển khoản, webhook kích hoạt trong 3s), ví MoMo, ZaloPay và In-App Purchase (Apple/Google).</li>
                  <li><strong>Chính sách cam kết:</strong> Hoàn tiền 100% trong 7 ngày đầu tiên nếu phụ huynh cảm thấy không phù hợp.</li>
                </ul>
              </div>
            </div>
          </section>

          {/* SECTION 5: Non-Functional Requirements */}
          <section id="sec-non-functional" className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs">
            <div className="flex items-center space-x-3 mb-6 pb-4 border-b border-slate-100">
              <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center font-bold">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-teal-700">Phần 5</span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                  Yêu cầu phi chức năng (Non-Functional Requirements)
                </h2>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                <span className="font-bold text-slate-900 text-sm block mb-2 flex items-center">
                  ⚡ Hiệu năng (Performance)
                </span>
                <ul className="space-y-2 text-slate-600">
                  <li><strong>AI Latency P95:</strong> Thời gian phản hồi chấm phát âm từ micro đến khi hiển thị màu &lt; 1.8 giây qua mạng 4G/Wi-Fi tiêu chuẩn Việt Nam.</li>
                  <li><strong>Chế độ Offline Prefetch:</strong> Cho phép tải trước toàn bộ âm thanh và hình ảnh của 1 Unit để bé học mượt mà ngay cả khi ngồi trên ô tô hoặc mất mạng.</li>
                  <li><strong>Tải trang &lt; 1.5 giây:</strong> Dung lượng gói ban đầu (Initial Bundle Size) &lt; 25MB để tải nhanh trên các điện thoại Android cấu hình phổ thông.</li>
                </ul>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                <span className="font-bold text-slate-900 text-sm block mb-2 flex items-center">
                  🛡️ An toàn trẻ em (Child Safety)
                </span>
                <ul className="space-y-2 text-slate-600">
                  <li><strong>100% No Third-Party Ads:</strong> Tuyệt đối không nhúng Google AdMob hay bất kỳ mạng quảng cáo ngoài nào vào ứng dụng.</li>
                  <li><strong>Tuân thủ Luật Trẻ em 2016 (VN) & COPPA:</strong> Không thu thập dữ liệu vị trí GPS, không yêu cầu ảnh thật của bé, bảo mật tuyệt đối thông tin gia đình.</li>
                  <li><strong>Parental Gate nghiêm ngặt:</strong> Bắt buộc có thử thách người lớn trước mọi hành vi thanh toán hoặc bấm link ra ngoài trình duyệt.</li>
                </ul>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                <span className="font-bold text-slate-900 text-sm block mb-2 flex items-center">
                  🎨 Thiết kế UI/UX Trẻ em
                </span>
                <ul className="space-y-2 text-slate-600">
                  <li><strong>Touch Target:</strong> Mọi nút bấm có kích thước tối thiểu 44 x 44px, khoảng cách giữa các lựa chọn ≥ 16px tránh trẻ chạm nhầm.</li>
                  <li><strong>Typography thân thiện:</strong> Sử dụng font tròn rõ ràng (như Plus Jakarta Sans, Nunito), cỡ chữ bài tập tối thiểu 18-20px để bé đọc rõ không mỏi mắt.</li>
                  <li><strong>Tương thích đa thiết bị:</strong> Tối ưu hoàn hảo cho cả màn hình điện thoại (Phone) và máy tính bảng (iPad/Android Tablet 10 inch).</li>
                </ul>
              </div>
            </div>
          </section>

          {/* SECTION 6: Risks & Mitigation */}
          <section id="sec-risks" className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs">
            <div className="flex items-center space-x-3 mb-6 pb-4 border-b border-slate-100">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-rose-700">Phần 6</span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                  Rủi ro & Giải pháp giảm thiểu (Risks & Mitigation)
                </h2>
              </div>
            </div>

            <div className="space-y-4">
              {PRD_RISKS.map((risk) => (
                <div key={risk.id} className="border border-slate-200 rounded-2xl p-4 bg-slate-50/60">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2 gap-2">
                    <div className="flex items-center space-x-2">
                      <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-slate-200 text-slate-800">
                        {risk.category}
                      </span>
                      <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                        {risk.risk}
                      </h4>
                    </div>
                    <div className="flex items-center space-x-2 text-[11px] shrink-0">
                      <span className="text-slate-500">Mức độ ảnh hưởng:</span>
                      <span className={`font-bold px-2 py-0.5 rounded-sm ${
                        risk.impact === 'Cao' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {risk.impact}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-slate-200/80 text-xs text-slate-700">
                    <span className="font-bold text-emerald-700 block mb-1">
                      ✅ Giải pháp kỹ thuật & sản phẩm khắc phục:
                    </span>
                    <p className="leading-relaxed">
                      {risk.mitigation}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </section>

        </div>
      </div>
    </div>
  );
};
