import React, { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  Users, 
  Activity, 
  ArrowRight,
  ShieldCheck,
  Zap,
  HelpCircle
} from 'lucide-react';

export const MetricsSimulator: React.FC = () => {
  const [monthlyInstalls, setMonthlyInstalls] = useState<number>(15000);
  const [conversionRate, setConversionRate] = useState<number>(6.8); // 6.8%
  const [retentionD7, setRetentionD7] = useState<number>(55); // 55%
  const [retentionD30, setRetentionD30] = useState<number>(32); // 32%
  const [yearPlanRatio, setYearPlanRatio] = useState<number>(65); // 65% pick 1-year plan
  const [cacInK, setCacInK] = useState<number>(180); // 180,000 VND CAC per paid user

  // Economics formulas
  const price6m = 590000;
  const price1y = 890000;
  const blendedArpu = Math.round((yearPlanRatio / 100) * price1y + ((100 - yearPlanRatio) / 100) * price6m);
  const paidUsersMonthly = Math.round(monthlyInstalls * (conversionRate / 100));
  const monthlyRevenueVND = paidUsersMonthly * blendedArpu;
  const annualRunRateVND = monthlyRevenueVND * 12;
  const cacTotalVND = cacInK * 1000;
  const ltvCacRatio = (blendedArpu / cacTotalVND).toFixed(1);

  // Funnel numbers
  const step1Installs = monthlyInstalls;
  const step2Onboarded = Math.round(step1Installs * 0.88);
  const step3CompletedLesson1 = Math.round(step2Onboarded * 0.76);
  const step4StreakDay7 = Math.round(step3CompletedLesson1 * (retentionD7 / 100));
  const step5ParentUnlocked = Math.round(step4StreakDay7 * 0.65);
  const step6PaidUsers = paidUsersMonthly;

  const formatVND = (amount: number) => {
    if (amount >= 1000000000) {
      return (amount / 1000000000).toFixed(2) + ' Tỷ VNĐ';
    }
    if (amount >= 1000000) {
      return (amount / 1000000).toFixed(1) + ' Triệu VNĐ';
    }
    return amount.toLocaleString('vi-VN') + ' VNĐ';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-200 gap-4 mb-6">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
              Unit Economics & Business Growth
            </span>
            <span className="text-xs text-slate-500 font-medium">Mô hình kinh doanh EdTech</span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 mt-1">
            Mô Phỏng Chỉ Số Thành Công & Dự Phóng Tài Chính
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Công cụ tính toán động cho Product Manager và Nhà sáng lập để đánh giá tính khả thi kinh tế (CAC, LTV, ARR, Phễu chuyển đổi).
          </p>
        </div>
      </div>

      {/* Main Grid: Sliders Controls + Revenue Output */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-8">
        {/* Controls Column */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
          <h3 className="font-extrabold text-slate-900 text-sm flex items-center">
            <Activity className="w-4 h-4 text-emerald-600 mr-2" />
            Biến số thị trường & Hành vi người dùng
          </h3>

          {/* Slider 1: Monthly Installs */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="font-bold text-slate-700">Lượt cài đặt mới / tháng:</span>
              <span className="font-mono font-bold text-amber-700">{monthlyInstalls.toLocaleString()} users</span>
            </div>
            <input
              type="range"
              min="2000"
              max="50000"
              step="1000"
              value={monthlyInstalls}
              onChange={(e) => setMonthlyInstalls(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          {/* Slider 2: Conversion Rate */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="font-bold text-slate-700">Tỷ lệ chuyển đổi Free &rarr; Paid:</span>
              <span className="font-mono font-bold text-emerald-700">{conversionRate}%</span>
            </div>
            <input
              type="range"
              min="2.0"
              max="12.0"
              step="0.2"
              value={conversionRate}
              onChange={(e) => setConversionRate(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400 block">Chuẩn EdTech Việt Nam: 3.5% - 5.5% (EduKids target 6.8%)</span>
          </div>

          {/* Slider 3: 1-Year Plan Ratio */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="font-bold text-slate-700">Tỷ lệ phụ huynh chọn Gói 1 Năm (890k):</span>
              <span className="font-mono font-bold text-indigo-700">{yearPlanRatio}%</span>
            </div>
            <input
              type="range"
              min="30"
              max="90"
              step="5"
              value={yearPlanRatio}
              onChange={(e) => setYearPlanRatio(Number(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-400 block">Còn lại {100 - yearPlanRatio}% chọn Gói 6 tháng (590k)</span>
          </div>

          {/* Slider 4: D7 Retention */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="font-bold text-slate-700">Tỷ lệ giữ chân Ngày thứ 7 (D7 Retention):</span>
              <span className="font-mono font-bold text-sky-700">{retentionD7}%</span>
            </div>
            <input
              type="range"
              min="20"
              max="70"
              step="1"
              value={retentionD7}
              onChange={(e) => setRetentionD7(Number(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
          </div>

          {/* Slider 5: CAC */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="font-bold text-slate-700">Chi phí Marketing / Trả phí (CAC):</span>
              <span className="font-mono font-bold text-rose-700">{cacInK * 1000} đ</span>
            </div>
            <input
              type="range"
              min="80"
              max="350"
              step="10"
              value={cacInK}
              onChange={(e) => setCacInK(Number(e.target.value))}
              className="w-full accent-rose-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Financial Highlights Column */}
        <div className="lg:col-span-7 space-y-6">
          {/* Big Output Banner */}
          <div className="bg-gradient-to-br from-slate-900 to-indigo-950 rounded-3xl p-6 sm:p-8 text-white shadow-xl border border-slate-800">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block mb-1">
              Dự phóng Doanh thu Hàng năm (Annual Run Rate - ARR)
            </span>
            <div className="text-3xl sm:text-5xl font-black text-white tracking-tight my-2">
              {formatVND(annualRunRateVND)}
            </div>
            <p className="text-xs text-slate-300">
              Dựa trên <strong>{paidUsersMonthly.toLocaleString()} phụ huynh trả phí/tháng</strong> với giá trị trung bình đơn hàng (ARPU) đạt <strong>{formatVND(blendedArpu)}</strong>.
            </p>

            <div className="grid grid-cols-3 gap-3 pt-6 mt-6 border-t border-slate-800 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Doanh thu tháng (MRR):</span>
                <span className="font-bold text-amber-300 text-sm sm:text-base">{formatVND(monthlyRevenueVND)}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Tỷ lệ LTV / CAC:</span>
                <span className="font-bold text-emerald-400 text-sm sm:text-base">{ltvCacRatio}x (Cực tốt)</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Thu hồi vốn (Payback):</span>
                <span className="font-bold text-sky-400 text-sm sm:text-base">&lt; 2.5 tháng</span>
              </div>
            </div>
          </div>

          {/* Key EdTech Metric Benchmarks */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
            <h4 className="font-extrabold text-slate-900 text-sm mb-4">
              So sánh Chỉ số với Chuẩn EdTech Tiểu học tại Việt Nam
            </h4>
            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-slate-600 font-medium">DAU / MAU Stickiness Ratio</span>
                <div className="text-right">
                  <span className="font-bold text-emerald-600">42% (Mục tiêu)</span>
                  <span className="text-[10px] text-slate-400 block">Thị trường: 28%</span>
                </div>
              </div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-slate-600 font-medium">Tỷ lệ hoàn thành Unit (Unit Completion)</span>
                <div className="text-right">
                  <span className="font-bold text-emerald-600">76% (Rất cao)</span>
                  <span className="text-[10px] text-slate-400 block">Thị trường: 45%</span>
                </div>
              </div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-slate-600 font-medium">Tỷ lệ gia hạn năm thứ 2 (Renewal Rate)</span>
                <div className="text-right">
                  <span className="font-bold text-emerald-600">68%</span>
                  <span className="text-[10px] text-slate-400 block">Chuyển tiếp lên SGK Tiếng Anh Lớp 5</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Visual Product Funnel */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs">
        <h3 className="font-extrabold text-slate-900 text-base mb-6 flex items-center">
          <TrendingUp className="w-5 h-5 text-amber-600 mr-2" />
          Mô hình Phễu Chuyển đổi Học viên (User Acquisition & Monetization Funnel)
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-6 gap-3 text-xs">
          {/* Step 1 */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-center flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">Bước 1</span>
              <h5 className="font-bold text-slate-900 mt-1">Lượt Tải App</h5>
              <span className="text-xl font-black text-slate-900 block my-2">{step1Installs.toLocaleString()}</span>
            </div>
            <span className="text-[10px] text-slate-500 font-medium">100% Cài đặt</span>
          </div>

          {/* Step 2 */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-center flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">Bước 2</span>
              <h5 className="font-bold text-slate-900 mt-1">Đăng ký & Chọn SGK</h5>
              <span className="text-xl font-black text-slate-900 block my-2">{step2Onboarded.toLocaleString()}</span>
            </div>
            <span className="text-[10px] text-emerald-600 font-bold">88% Hoàn tất</span>
          </div>

          {/* Step 3 */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-center flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">Bước 3</span>
              <h5 className="font-bold text-slate-900 mt-1">Học Xong Lesson 1</h5>
              <span className="text-xl font-black text-slate-900 block my-2">{step3CompletedLesson1.toLocaleString()}</span>
            </div>
            <span className="text-[10px] text-emerald-600 font-bold">76% Kích hoạt</span>
          </div>

          {/* Step 4 */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-center flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">Bước 4</span>
              <h5 className="font-bold text-slate-900 mt-1">Học Liên Tục D7</h5>
              <span className="text-xl font-black text-sky-700 block my-2">{step4StreakDay7.toLocaleString()}</span>
            </div>
            <span className="text-[10px] text-sky-600 font-bold">{retentionD7}% Giữ chân</span>
          </div>

          {/* Step 5 */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-center flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">Bước 5</span>
              <h5 className="font-bold text-slate-900 mt-1">Mẹ Nhận Báo Cáo Zalo</h5>
              <span className="text-xl font-black text-indigo-700 block my-2">{step5ParentUnlocked.toLocaleString()}</span>
            </div>
            <span className="text-[10px] text-indigo-600 font-bold">65% Tin cậy</span>
          </div>

          {/* Step 6 */}
          <div className="bg-amber-50 p-4 rounded-2xl border-2 border-amber-400 text-center flex flex-col justify-between shadow-2xs">
            <div>
              <span className="text-[10px] font-bold text-amber-800 uppercase">Bước 6</span>
              <h5 className="font-bold text-amber-950 mt-1">Mua Gói VIP</h5>
              <span className="text-xl font-black text-amber-700 block my-2">{step6PaidUsers.toLocaleString()}</span>
            </div>
            <span className="text-[10px] text-amber-900 font-black">{conversionRate}% Chuyển đổi</span>
          </div>
        </div>
      </div>
    </div>
  );
};
