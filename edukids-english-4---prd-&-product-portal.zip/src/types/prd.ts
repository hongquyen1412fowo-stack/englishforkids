export type PrdSectionId = 
  | 'overview' 
  | 'personas' 
  | 'user-flows' 
  | 'functional-requirements' 
  | 'non-functional' 
  | 'risks-mitigation'
  | 'release-roadmap';

export interface UserPersona {
  id: string;
  type: 'primary' | 'secondary';
  name: string;
  role: string;
  age: string;
  avatar: string;
  bio: string;
  painPoints: string[];
  goals: string[];
  techHabits: string[];
  quote: string;
}

export interface UserStory {
  id: string;
  module: string;
  epic: string;
  title: string;
  asA: string;
  iWantTo: string;
  soThat: string;
  acceptanceCriteria: string[];
  priority: 'Must Have' | 'Should Have' | 'Could Have';
  phase: 'MVP (Giai đoạn 1)' | 'Phase 2 (Mở rộng)';
  storyPoints: number;
  technicalNotes?: string;
}

export interface TextbookInfo {
  id: 'global-success' | 'family-friends' | 'smart-start';
  name: string;
  publisher: string;
  marketShare: string;
  totalUnits: number;
  sampleUnit: {
    unitNumber: number;
    title: string;
    theme: string;
    targetVocab: { word: string; ipa: string; meaning: string; phonemes: { phoneme: string; status: 'green' | 'yellow' | 'red' }[] }[];
    targetSentence: string;
    sampleConversation: { speaker: string; text: string; vn: string }[];
  };
}

export interface PrdRisk {
  id: string;
  category: 'Công nghệ AI' | 'Học liệu & Pháp lý' | 'Hành vi & Trẻ em' | 'Thương mại & Thanh toán';
  risk: string;
  impact: 'Cao' | 'Trung bình' | 'Thấp';
  probability: 'Cao' | 'Trung bình' | 'Thấp';
  mitigation: string;
}
